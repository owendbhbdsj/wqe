
local test = CreateSprite("bullet")
test.Remove()
isRetro = test.isactive
test = nil

if (not isRetro) and (CYFversion ~= "1.0" and CYFversion >= "0.6.2.1") then
	if (GetAlMightyGlobal("CMDEncounter") == nil) then
		SetAlMightyGlobal("CMDEncounter", "monika")
	end

	SetAlMightyGlobal("CMDEncounter", "monika")
	--SetAlMightyGlobal("CMDEncounter", "nooseFactory")
	--SetAlMightyGlobal("CMDEncounter", "OldVer")
	--SetAlMightyGlobal("CMDEncounter", "laboratory")

	require ("fakeEncounters/" .. GetAlMightyGlobal("CMDEncounter"))
	--Misc.FullScreen = true
else
	require("fakeEncounters/OldVer")
end

