-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"JEVILKA is laughing\n incomprehensibly."}
commands = {"Check", "Pirouette"}
if (NewAudio ~= nil) then
	NewAudio.CreateChannel( "sfx")
end

sprite = "narrator" --Always PNG. Extension is added automatically.
name = "JEVILKA"
hp = 10000
atk = 10
def = -20
dialogbubble = "rightwide" -- See documentation for what bubbles you have available.
canspare = false
cancheck = false
currentdialogue = "Test Text"

pirouetteCount = 0

hurtSounds = {"Jevilka/ha0", "Jevilka/ha1", "Jevilka/laugh0", "Jevilka/laugh1", "Jevilka/oh"}

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    Encounter.Call("ChangeMonikaAnim", {3, attackstatus})
    NewAudio.PlaySound( "sfx",  hurtSounds[math.random(1, #hurtSounds)],  false,  0.8)
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "CHECK" then
        BattleDialog({"All information on this\nfoe has been deleted.", "So, good luck, pal."})
    elseif command == "PIROUETTE" then
        BattleDialog({"You spun around.[w:12]\nJEVILKA got slightly \nmore tired[w:5], and . . ."})
        pirouetteCount = pirouetteCount + 1
        NewAudio.PlaySound( "sfx",  "DR/snd_magicsprinkle",  false,  0.8)
    end
end

function Transformation(s)
    Encounter["BG"].image.xscale = 16/15
    Encounter["BG"].image.y = 260
    Encounter["BG"]["isactive"] = true
    Encounter.Call("SwitchMonikas")
    Encounter.Call("ChangeButtons")
    if not s then
        Encounter.Call("StartFade", {1, 0, 60})
    else
        EndIntro()
    end
end

function Flash()
    Encounter.Call("StartFade", {0, 1, 30})
    NewAudio.PlaySound( "sfx",  "snd_magicsprinkle_moded",  false,  0.8)
end

function EndIntro()
    State("ACTIONSELECT")
    Encounter["isIntro"] = nil
    Audio.LoadFile("THE WORLD REVOLVING")
    Audio.Volume(0.75)
    Audio.Pitch(1)
    Encounter["nextwaves"] = {"nothing"}
    Encounter["skipIcon"].alpha = 0
    voice = "Jevilka"
end

function TheJokersWind()
    Audio.LoadFile("Circus")
    Audio.Volume(0.20)
    --Audio.Pitch(0.5)
end

MResp1 = {
    "[voice:Jevilka]OH[w:8], IT'S JUST A \nSIMPLE NUMBERS \nGAME.", 
    "[voice:Jevilka]WHEN YOUR HP DROPS TO 0[w:8], YOU LOSE!",
    "[func:MCInterrupt,MCResp2,MResp2]"
}
MResp2 = {
    "[voice:Jevilka][w:20]UE HE HE![w:10] SHARK-TO-SHARK![w:10] I WOULDN'T HAVE IT \nANY OTHER WAY!", 
    "[voice:Jevilka]NOW[w:8], NOW[w:8], LET THE GAMES BEGIN!",
    "[func:EndIntro]"
}

function MonikaInterrupt(varName)
    DEBUG("Monika's turn")
    currentdialogue = _G[varName]
    State("ENEMYDIALOGUE")
end

MCResp1 = {"[func:EndIntro]So what are we gonna play, exactly . . . ?"}
MCResp2 = {"So that's the kinda game you wanna play[w:8], huh. . . ?", "Then[w:8], I gotta warn you . . .", "You're dealing with a couple of sharks."}

function MCInterrupt(varName, varName2)
    BattleDialog(_G[varName])
    currentdialogue = _G[varName2]
end