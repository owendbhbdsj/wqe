-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"[func:RealComments]It's just Monika."}
commands = {"Check", "Act 1", "Act 2", "Act 3"}
currentdialogue = {''}
--randomdialogue = {"Rand dial."}

sprite = "nothing" --Always PNG. Extension is added automatically.
name = "Monika"
hp = 300
atk = 8
def = 8
check = "Poet, musician and a dirty hacker."
dialogbubble = "rightwide" -- See documentation for what bubbles you have available.
canspare = false
cancheck = false

monikaCurious = true

-- Happens after the slash animation but before 
function HandleAttack(damage)
    if attackstatus == -1 then
		if (monikaCurious) then
			currentdialogue = {"[w:15]. [w:15]. [w:15]. [w:15] ?", "What are you doing?", "You were supposed to hit me there, right?"}
			Encounter["nextwaves"] = {"nothing"}
			monikaCurious = false
		end
    elseif (damage == 0) then

	elseif (damage > 0) then
        if (hp <= 0) then
			hp = 1
		end
		MHurt()
    end
end

currTalk = 0

-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if (command == "ACT 1" or command == "ACT 2" or command == "ACT 3") then
        currentdialogue = {"Oh jeez.", "Did I not implement any ACT options?", "I must have forgot!", "I am sorry about that.[w:10]\nJust give me a sec."}
		BattleDialog({"You selected " .. command .. "."})
		commands = {"Check", (Encounter["currAttack"] >= 28 and "[color:00c000]Talk[color:ffffff]" or "Talk") ,"Flirt"}
		SetAlMightyGlobal("MonikaAct", true)
		Encounter["nextwaves"] = {"nothing"}
    elseif command == "CHECK" then
		BattleDialog({"MONIKA 8 ATK 10 DEF\nPoet, musician and a dirty hacker[w:5][next].", "[instant]MONIKA 8 ATK 10 DEF\nPoet, musician [instant:stop]and a professional programmer.", "You can't ask for more than her."})
	elseif command == "FLIRT" then
		BattleDialog({"You shrug seductively.[w:10]\nMonika doesn't know what to make of it."})
	elseif command == "TALK" then
		BattleDialog({"You wanted to say something[w:8]. [w:8]. [w:8].[w:18]\nBut you have trouble with the wording."})
	elseif command == "[COLOR:00C000]TALK[COLOR:FFFFFF]" then
		currTalk = currTalk + 1
		currentdialogue = {table.unpack(Encounter["talk_responses"][math.min(currTalk, #Encounter["talk_responses"])])}
		BattleDialog(Encounter["talk_options"][math.min(currTalk, #Encounter["talk_options"])])
		--DEBUG(currTalk .. ' :: ' .. #Encounter["talk_options"] .. " :: " .. Encounter["talk_options"][math.min(currTalk, #Encounter["talk_options"])])
	end
end

function SwapSong(song)
	Audio.LoadFile(song)
end

hitMultReq = 1

function BeforeDamageCalculation()
	local damage = -1
	hit = CreateSprite("glitchKnife/0", "BelowArena")
	hit.MoveTo(320, 345)
	if Player.lasthitmultiplier > hitMultReq then
		hit.SetAnimation({"UI/Battle/spr_slice_o_0", "UI/Battle/spr_slice_o_1", "UI/Battle/spr_slice_o_2", "UI/Battle/spr_slice_o_3", "UI/Battle/spr_slice_o_4","UI/Battle/spr_slice_o_5"}, 0.2)
		hitMultReq = math.min(hitMultReq + 0.15, 1.8)
	else
		hit.SetAnimation({"glitchKnife/0", "glitchKnife/1", "glitchKnife/2", "glitchKnife/3", "glitchKnife/4","glitchKnife/5"}, 0.2)
		SetDamage(0)
		damage = 0
	end
	hit.loopmode = "ONESHOTEMPTY"
	
	if (Encounter["mState"] == 1 and canspare) then
		SetDamage(999)
		damage = 999
		hit.SetAnimation({"UI/Battle/spr_slice_o_0", "UI/Battle/spr_slice_o_1", "UI/Battle/spr_slice_o_2", "UI/Battle/spr_slice_o_3", "UI/Battle/spr_slice_o_4","UI/Battle/spr_slice_o_5"}, 0.2)
		Encounter["nextwaves"] = {"nothing"}
		currentdialogue = {	"[func:Shake][func:MFace,21]Hnnnn[w:6]. [w:6]. [w:6].", 
							"[func:MFace,12][waitall:2]So [w:6]. [w:6]. [w:6].", 
							"[func:MFace,21]Is[w:10] this how it feels like?", 
							"[func:MFace,13]Is[w:12][func:MFace,21] this what they have felt?",
							"[w:12]. [w:12]. [w:12].",
							"Why[w:12][func:MFace,12][waitall:2] does it hurt so much?",
							"[waitall:2]I am in a virtual environment, after all.",
							"This [w:8]. [w:8]. [w:8]. [waitall:2] is an everyday activity here[w:10], right?",
							"[waitall:2]" .. Misc.MachineName .. "[w:10], I'm sorry.",
							"[waitall:2]I shouldn't have put them through those traumatic events.",
							"[waitall:3][func:MFace,22]But[w:10], hey[w:10], looks like you have defeated me.",
							"[waitall:3]Claim your prize[w:12], hero.", "[noskip][func:KillM][w:20][func:Credits] "
						}
		for i=1, #currentdialogue do currentdialogue[i] = "[effect:shake,0.9]" .. currentdialogue[i] end
		Audio.Stop()
	end
	
	if (damage == 0) then
		Encounter["animtimer"] = 0
		Encounter["mastate"] = 3
	end
end

function introStart()
	Encounter.Call("introStart")
	bg.Remove()
	bg = nil
end

function disclaimerStart()
	bg = CreateSprite("intro/black", "Disclaimer")
	bg.Scale(640, 480)
	bg.MoveTo(320, 240)
end

function KillM()
	Encounter.Call("KillM")
end

function Credits()
	SetAlMightyGlobal("MonikaWins", 1)
	Misc.DestroyWindow()
end

function Close()
	State("DONE")
end

function OnSpare()
	currentdialogue = {"Allright then. Let's go!", "[func:Credits]"}
	State("ENEMYDIALOGUE")
end

function Choice()
	--canspare = true
	comments = {"Monika's looking troubled."}
	if (commands[2] == "Talk") then
		commands[2] = "[color:00c000]Talk[color:ffffff]"
	end
end

function PauseSong()
	Audio.Pause()
end

function UnpauseSong()
	Audio.Unpause()
end

function MHurt()
	Encounter["maarg"] = 4
	Encounter.Call("MonikaExpression")
	Encounter["animtimer"] = 0
	Encounter["mastate"] = 2
end

function MFace(id)
	Encounter["maarg"] = id
	Encounter.Call("MonikaExpression")
end

function MTorso(t)
	Encounter["maarg"] = (t == "true" and true or false)
	Encounter.Call("MonikaHand")
end

function Heal(a)
	Player.Heal(a)
	if Player.hp == Player.maxhp then
		return "Your HP was maxed out."
	else
		return "You recovered " .. a .. " HP."
	end
end

function Shake()
	Encounter["mastate"] = 4
	Encounter["animtimer"] = 0
end

function SpiderInit()
	Audio.Pause()
	NewAudio.PlayMusic( "Amy", "Amy Likes Spiders",  true)
end

function DisclaimerDone() 
	Encounter.Call("DisclaimerDone") 
end