
timer = 0
knives = {}
Encounter["wavetimer"] = 60
Arena.Resize(100, 100)

Encounter.Call( "toggleMonika", {100, true})
Encounter["ignoreNextFade"] = true

Audio.PlaySound("warning1")

function Update()
	timer = timer + 1
	for i=1,#knives do
		local k = knives[i]
		if (k.isactive) then
			k.setVar("timer", k.getVar("timer") + 3)
			if (k.getVar("timer") <= 300) then
				RotationBasedMovement(k.sprite, math.sin(math.rad(k.getVar("timer")))* 2)
			else
				RotationBasedMovement(k.sprite, 10)
				k.setVar("alpha", k.getVar("alpha") - 0.1)
				k.sprite.alpha = k.getVar("alpha")
				if (k.sprite.alpha <= 0) then
					k.Remove()
				end
			end
		end
	end

	if (timer == 33) then
		Audio.PlaySound("Intense anime jump")
	elseif (timer >= 140) then
		Encounter["enemies"][1]["currentdialogue"] = (Player.hp == Player.maxhp and {"[func:MFace,19]Ah.[w:10][func:MFace,12] Sorry.", "I[w:5]-I didn't look where\nI was pressing!", "And I accidentally launched an attack instead of just preparing it.", "[func:MFace,18]Thank god you have such good reflexes.","[func:MFace,12]Still, I'm so very sorry.", "[func:MFace,1]We'll start off easy now[w:5], alright?", "[func:State,ACTIONSELECT]"} or {"[func:MFace,19]Ah.[w:10][func:MFace,12] Sorry.", "I[w:5]-I didn't look where\nI was pressing!", "And I accidentally launched an attack instead of just preparing it.", "[func:MFace,1]Here, let me [func:Heal,20]heal you.","[func:MFace,12]I'm so very sorry.", "[func:MFace,1]We'll start off easy now[w:5], alright?", "[func:State,ACTIONSELECT]"})
		State("ENEMYDIALOGUE")
	end
end

function OnHit()
	if (Player.hp > 1) then
		PHurt(Player.hp - 1, 3)
	end
end

function SummonKnife(a)
	local x = math.sin(math.rad(a)) * 110
	local y = math.cos(math.rad(a)) * 110
	local k = CreateProjectile("Knife" .. math.random(1,3), x, y)
	k.ppcollision = true
	PointTo(k, 0, 0)
	k.setVar("timer", 200)
	k.setVar("alpha", 4.5)
	table.insert(knives, k)
	return k
end

require "waveBasic"

for i=1, 20 do
	SummonKnife(i*5 - 50)
end