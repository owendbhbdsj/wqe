
safety = CreateSprite("Safe" .. math.random(1,4), "BelowBullet")
Arena.Resize(450, 100)
safety.MoveTo(Arena.x, Arena.y + Arena.height/2 + 10)

Encounter["wavetimer"] = 10.0

function Update()

end

function OnHit()

end

function EndingWave()
	safety.Remove()
	safety = nil
end

require "waveBasic"