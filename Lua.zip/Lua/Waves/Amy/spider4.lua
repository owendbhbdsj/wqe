

timer = 0
Encounter["wavetimer"] = 5
orgHP = Player.hp
wavestopped = false

function Update()
	PPlayerManager()
	PSpiderManager()
	
	timer = timer + 1
	if (timer % 60 == 0) then
		SummonSpider(1, -1, 1.5)
		SummonSpider(2, 1, 1.5)
	end
	if (timer % 60 == 0) then
		Player.hp = Player.hp + 1
	end
	if wavestopped then
		EndWave()
	end
end

function OnHit()
	Player.hp = math.max(orgHP-5, 1)
	wavestopped = true
end

function EndingWave()
	NewAudio.Stop("Amy")
	Audio.Unpause()
end

require "purple soul"

SpiderSetUp(2, 250, 1)

require "waveBasic"