

timer = 0
Encounter["wavetimer"] = 5
orgHP = Player.hp
wavestopped = false

function Update()
	PPlayerManager()
	PSpiderManager()
	PCSpiderManager()
	
	timer = timer + 1
	if (timer % 40 == 0) then
		SummonSpider(math.random(1, 3), (math.random(0, 1) == 0 and -1 or 1), 3)
	end
	if (timer % 80 == 0) then
		SummonCeilingSpider(Player.x, 2)
	end
	
	if (timer % 60 == 0) then
		Player.hp = Player.hp + 1
	end
	if wavestopped then
		EndWave()
	end
end

function OnHit()
	Player.hp = math.max(orgHP-5, 1)
	wavestopped = true
end

function EndingWave()
	NewAudio.Stop("Amy")
	Audio.Unpause()
end

require "purple soul"

SpiderSetUp(3, 250, 2)

require "waveBasic"