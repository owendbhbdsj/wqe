

timer = 0
distance = 125
Encounter["wavetimer"] = 5
orgHP = Player.hp
wavestopped = false

function Update()
	PPlayerManager()
	PSpiderManager()
	PCSpiderManager()
	
	timer = timer + 1
	if (timer % 5 == 0 and timer <= 115) then
		SummonCeilingSpider(distance, 4)
		distance = distance - 10
	end
	if (timer == 120) then
		distance = -125
	end
	if (timer % 5 == 0 and timer >= 150 and timer <= 260) then
		SummonCeilingSpider(distance, 4)
		distance = distance + 10
	end
	
	if (timer % 60 == 0) then
		Player.hp = Player.hp + 1
	end
	if wavestopped then
		EndWave()
	end
end

function OnHit()
	Player.hp = math.max(orgHP-5, 1)
	wavestopped = true
end

function EndingWave()
	NewAudio.Stop("Amy")
	Audio.Unpause()
end


require "purple soul"

SpiderSetUp(1, 250, 1)
Player.MoveTo(125, Player.y)
Arena.Resize(Arena.width, Arena.height + 50)

require "waveBasic"