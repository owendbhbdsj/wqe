
timer = 0
sinus = 0
cupcakes = {}
Encounter["wavetimer"] = 10
Arena.Resize(200, 100)

function Update()
	timer = timer + 1
	if (timer % 10 == 0) then
		for i=1, 10 do
			if (i < 5 or i > 6) then
				local cupcake = CreateProjectile("cupcake", (-Arena.width/2)+20*(i-1)+10 + math.sin(math.rad(sinus))*100, 510)
				cupcake.sprite.MoveToAbs(cupcake.absx, 510)
				table.insert(cupcakes, cupcake)
			end
		end
		sinus = sinus + 5
	end
	
	SelectProjectileAction( cupcakes, CupcakeDo)
end

function CupcakeDo(cupcake)
	cupcake.sprite.y = cupcake.sprite.y - 4
	if (cupcake.sprite.y <= 0) then
		cupcake.Remove()
	end
	
	local deltax = Player.x - cupcake.x
	local deltay = Player.y - cupcake.y
	local distance = math.sqrt((deltax * deltax) + (deltay * deltay))
	if distance < 100 then
		cupcake.sprite.color = {1-(distance/100), 192/255 + (distance/25500), 1-(distance/100)}
	else
		cupcake.sprite.color = {0, 192/255, 0}
	end
end

function OnHit(bullet)
	PHurt(3, 1)
end

require "waveBasic"