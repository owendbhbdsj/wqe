
timer = 0
cupcakes = {}
warns = {}
Encounter["wavetimer"] = 10
lastRand = 5
Arena.Resize(200, 100)

function Update()
	timer = timer + 1
	if (timer % 50 == 0) then
		local rand = PickRandom()
		lastRand = rand
		for i=1, 10 do
			if (i < rand or i > rand+1) then
				local warn = CreateProjectile("intro/white", (-Arena.width/2)+20*(i-1)+10, 510)
				warn.sprite.MoveToAbs(warn.absx, 510)
				warn.sprite.color = {1, 0, 0}
				warn.sprite.Scale(20, 1300)
				warn.sprite.layer = "BelowPlayer"
				warn.sprite.alpha = 0.6
				warn.setVar("timer", 0)
				warn.setVar("color", "r")
				table.insert(warns, warn)
				
				Audio.PlaySound("bullet warning")
			end
		end
	end
	
	SelectProjectileAction( warns, WarnDo)
	SelectProjectileAction( cupcakes, CupcakeDo)
end

function CupcakeDo(cupcake)
	cupcake.sprite.y = cupcake.sprite.y + 10 * cupcake.getVar("dir")
	if (cupcake.y <= -Arena.height/2) then
		cupcake.setVar("dir", 1)
	end
	if (cupcake.sprite.y >= 600) then
		cupcake.Remove()
	end
	
	local deltax = Player.x - cupcake.x
	local deltay = Player.y - cupcake.y
	local distance = math.sqrt((deltax * deltax) + (deltay * deltay))
	if distance < 100 then
		cupcake.sprite.color = {1-(distance/100), 192/255 + (distance/25500), 1-(distance/100)}
	else
		cupcake.sprite.color = {0, 192/255, 0}
	end
end

function WarnDo(warn)
	warn.setVar("timer", warn.getVar("timer") + 1)
	if (warn.getVar("timer") >= 20) then
		local cupcake = CreateProjectile("cupcake", warn.x, warn.y)
		cupcake.setVar("color", "w")
		cupcake.setVar("dir", -1)
		table.insert(cupcakes, cupcake)
		warn.Remove()
		Audio.PlaySound("falling")
	end
end

function PickRandom()
	local r = math.max(math.min(lastRand + math.random(-2, 2), 9), 1)
	if (r == lastRand) then
		r = PickRandom()
	end
	lastRand = r
	return r
end

function OnHit(bullet)
	if (bullet.getVar("color") == "w") then
		PHurt(3, 1)
	end
end

require "waveBasic"