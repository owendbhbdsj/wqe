
spawntimer = 0
bullets = {}
Encounter["wavetimer"] = 10
Arena.Resize(200, 100)

function Update()
    spawntimer = spawntimer + 1
    if spawntimer%20 == 0 then
        local posx = math.random(-80, 80)
        local posy = 150
        local bullet = CreateProjectile('cupcake', posx, posy)
        bullet.SetVar('velx', 1 - 2*math.random())
        bullet.SetVar('vely', 0)
        table.insert(bullets, bullet)
    end
    
    for i=1,#bullets do
        local bullet = bullets[i]
        local velx = bullet.GetVar('velx')
        local vely = bullet.GetVar('vely')
        local newposx = bullet.x + velx
        local newposy = bullet.y + vely
        if(bullet.x > -Arena.width/2 and bullet.x < Arena.width/2) then
            if(bullet.y < -Arena.height/2 + 8) then 
                newposy = -Arena.height/2 + 8
                vely = 4
            end
        end
        vely = vely - 0.04
        bullet.MoveTo(newposx, newposy)
        bullet.SetVar('vely', vely)
		
		local deltax = Player.x - bullet.x
		local deltay = Player.y - bullet.y
		local distance = math.sqrt((deltax * deltax) + (deltay * deltay))
		if distance < 100 then
			bullet.sprite.color = {1-(distance/100), 192/255 + (distance/25500), 1-(distance/100)}
		else
			bullet.sprite.color = {0, 192/255, 0}
		end
    end
end

function OnHit(bullet)
	PHurt(3, 1)
end

require "waveBasic"