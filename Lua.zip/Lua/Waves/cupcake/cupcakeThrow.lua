
timer = 0
isRight = true
cupcakes = {}
Encounter["wavetimer"] = 10
Arena.Resize(100, 150)

function Update()
	timer = timer + 1
	if (timer % 20 == 0) then
		local cupcake = CreateProjectile("cupcake", (isRight and 350 or -350), Player.y)
		cupcake.setVar("speed", (isRight and -5 or 5))
		table.insert(cupcakes, cupcake)
		isRight = not isRight
		
		Audio.PlaySound("Finger Gun")
	end
	
	SelectProjectileAction( cupcakes, CupcakeDo)
end

function CupcakeDo(cupcake)
	cupcake.Move(cupcake.getVar("speed"), 0)
	if (math.abs(cupcake.x) > 350) then
		cupcake.Remove()
	end
end

function OnHit(bullet)
	PHurt(3, 1)
end

require "waveBasic"