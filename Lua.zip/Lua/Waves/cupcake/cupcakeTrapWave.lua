
timer = 0
bullets = {}
Encounter["wavetimer"] = 12
Arena.Resize(640, 80)

function Update()
	timer = timer + 1
	if (timer % 80 == 0) then
		for i=1, 5 do
			local bullet = CreateProjectile("cupcake", 1000, 1000)
			bullet.setVar("timer", 1)
			bullet.MoveTo(-1*(340+23*i), i * 25)
			bullet.setVar("dir", 1)
			bullet.setVar("MoveF", WaveMove)
			table.insert(bullets, bullet)
		end
	end

	if (timer % 30 == 0) then
		local bullet = CreateProjectile("cupcake", Player.x + math.random(-50, 50), 420)
		bullet.setVar("timer", 1)
		bullet.setVar("speed", 15)
		bullet.setVar("MoveF", MoveDown)
		table.insert(bullets, bullet)
	end

	for i=1,#bullets do
        local bullet = bullets[i]
        bullet.setVar("timer", (bullet.getVar("timer") or 0) + 1)
        bullet.getVar("MoveF")(bullet)
		
		local deltax = Player.x - bullet.x
		local deltay = Player.y - bullet.y
		local distance = math.sqrt((deltax * deltax) + (deltay * deltay))
		if distance < 100 then
			bullet.sprite.color = {1-(distance/100), 192/255 + (distance/25500), 1-(distance/100)}
		else
			bullet.sprite.color = {0, 192/255, 0}
		end
    end
end

function OnHit()
	PHurt(3, 1)
end

function WaveMove(bullet)
	bullet.MoveTo(bullet.x + 5, bullet.y + (bullet.getVar("dir")*3) )
	if (bullet.y >= Arena.height/2 - 10 and bullet.getVar("dir") == 1) or (bullet.y <= -Arena.height/2 + 10 and bullet.getVar("dir") == -1) then
		bullet.setVar("dir", bullet.getVar("dir") * -1)
	end
end

function MoveForward(bullet)
	bullet.setVar("speed", bullet.getVar("speed") + 0.1)
	bullet.x = bullet.x + bullet.getVar("speed")
end

function MoveDown(bullet)
	bullet.setVar("speed", math.max(bullet.getVar("speed") - 0.5, 1))
	bullet.y = bullet.y - bullet.getVar("speed")
end

require "waveBasic"