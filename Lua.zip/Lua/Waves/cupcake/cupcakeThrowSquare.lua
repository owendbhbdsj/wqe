
timer = 0
currSide = 0
cupcakes = {}
Encounter["wavetimer"] = 10
Arena.Resize(40, 40)
sides = {{x = -350, y = -20, r = 0}, {x = 20, y = -350, r = 90}, {x = 350, y = 20, r = 180}, {x = -20, y = 350, r = 270}}
Player.MoveTo(20, -20, false)

function Update()
	timer = timer + 1
	if (timer % 30 == 0) then
		local cupcake = CreateProjectile("cupcake", sides[(currSide%4)+1].x, sides[(currSide%4)+1].y)
		cupcake.sprite.rotation = sides[(currSide%4)+1].r
		table.insert(cupcakes, cupcake)
		currSide = currSide + 1
		
		Audio.PlaySound("Finger Gun")
	end
	
	SelectProjectileAction( cupcakes, CupcakeDo)
end

function CupcakeDo(cupcake)
	RotationBasedMovement(cupcake.sprite, 15)
	if (math.abs(cupcake.x) > 350 or math.abs(cupcake.y) > 350) then
		cupcake.Remove()
	end
end

function OnHit(bullet)
	PHurt(3, 1)
end

require "waveBasic"