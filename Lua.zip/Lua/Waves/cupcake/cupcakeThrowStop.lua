
timer = 0
isRight = true
cupcakes = {}
Encounter["wavetimer"] = 10
Arena.Resize(40, 80)

function Update()
	timer = timer + 1
	if (timer % 20 == 0) then
		local cupcake = CreateProjectile("cupcake", (isRight and 350 or -350), 80)
		cupcake.setVar("speed", (isRight and -5 or 5))
		cupcake.setVar("phase", 0)
		cupcake.setVar("sin", 0)
		table.insert(cupcakes, cupcake)
		isRight = not isRight
		
		Audio.PlaySound("Finger Gun")
	end
	
	SelectProjectileAction( cupcakes, CupcakeDo)
end

function CupcakeDo(cupcake)
	if (cupcake.getVar("phase") == 0) then
		cupcake.Move(cupcake.getVar("speed"), 0)
		if (cupcake.x*cupcake.getVar("speed")/5 >= 15) then
			cupcake.setVar("phase", 1)
			Audio.PlaySound("falling")
		end
	else
		cupcake.setVar("sin", math.min(cupcake.getVar("sin")+1, 90))
		cupcake.Move(0, -(math.sin(math.rad(cupcake.getVar("sin")))*5))
	end
	if (cupcake.absy < -50) then
		cupcake.Remove()
	end
end

function OnHit(bullet)
	PHurt(3, 1)
end

require "waveBasic"