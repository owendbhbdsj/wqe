
Arena.ResizeImmediate(565, 130)

function Update()
	EndWave()
end

