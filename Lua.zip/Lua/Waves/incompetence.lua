Audio.Stop()
Player.SetControlOverride(true)
Player.MoveTo(1000, 1000, true)
if isCYF and (CYFversion ~= "1.0" and CYFversion >= "0.6.2.1") then
	bonus = false
	sprite = "OldVer/RetroMode"
else
	bonus = false
	sprite = (CYFversion == nil and "OldVer/Unitale" or "OldVer/CYFOld")
end
cover = CreateProjectileAbs( sprite, 320, 240)
isMenu = false

function Update()
	if Input.Menu == 1 and bonus and (not isMenu) then
		cover.sprite.Set("OldVer/BrokenMenu")
		isMenu = true
	end
	if Input.Confirm == 1 and isMenu then
		cover.Remove()
		cover = nil
		Encounter["isIntro"] = true
		Encounter["enemies"][1]["currentdialogue"] = { 
			"Welcome back, " .. Misc.MachineName .. ".",
			"Sorry for the \nsudden combat stand.",
			"There must have \nbeen a small bug in the code.",
			"Let me try to fix it.",
			"[w:120]Ummm [w:8]. [w:8]. [w:8]. [w:20]" .. Misc.MachineName .. "?",
			"Did you [w:8]. [w:8]. [w:8]. [w:20] run\nthe mod in Retrocompatibility Mode?",
			"I mean, it's much better than trying \nto open me in \nRegular Unitale [w:8]. [w:8]. [w:8].",
			"But still[w:10], that's [w:8]. [w:8]. [w:8]. [w:20] \nsomething that I didn't really prepare for.",
			"Now almost none of my normal attacks will work.",
			"At least[w:5], according to the Docs.",
			"Hmmmm [w:8]. [w:8]. [w:8].",
			"Well, the only thing I have prepared right now is [w:8]. [w:8]. [w:8].",
			"Well [w:8]. [w:8]. [w:8]. [w:20]",
			"A slightly improved version of an old school play.",
			"From back when I was a part of the Drama Club.",
			"Shall we try that one?",
			"[noskip]I mean, it wouldn't hurt[w:10], would[func:Flash] it?[w:90][next]",
			"[noskip][func:Transformation,false][w:10][func:TheJokersWind][w:80][next]", 
			"All right, I'm ready!",
			"Umm[w:10], I mean.",
			"Ehem.",
			"[voice:Jevilka]UEE HEE![w:20]\nVISITOR![w:10] VISITOR![w:20]\nNOW WE CAN PLAY[w:10], PLAY!",
			"[voice:Jevilka]AND[w:8], AFTER YOU[w:8], I \nCAN PLAY WITH EVERYONE ELSE[w:8], TOO!",
			"[speed:2](Wait[w:4], this doesn't \nfit the context.)[w:20][next]",
			"[func:MCInterrupt,MCResp1,MResp1]"
			}
		State("ENEMYDIALOGUE")
	end
end

function OnHit()

end