
require "ButtonSummon"

timer = 0
Encounter["wavetimer"] = 500.0

waveState = 2

nextWaveState = 1

cupcakes = {}
cupcakeO = true

knives = {}
buttons = {}

function Update()
	timer = timer + 1
	waveStates[waveState]()
end

function OnHit(bullet)
	local c = bullet.getVar("color")
	if (c == "w") then
		PHurt(bullet.getVar("dmg") or 5, bullet.getVar("inv") or 1)
	elseif (c == "c") and isPlayerMoving then
		PHurt(bullet.getVar("dmg") or 5, bullet.getVar("inv") or 1)
	elseif (c == "o") and (not isPlayerMoving) then
		PHurt(bullet.getVar("dmg") or 5, bullet.getVar("inv") or 1)
	end
end

function EndingWave()
	if not(fakeBG == nil) then
		fakeBG.Remove()
		fakeBG = nil
	end
	for i=1, #buttons do
		if (not (buttons[i].getVar("warn") == nil)) then
			buttons[i].getVar("warn").Remove()
		end
	end
	Player.sprite.color = {1, 0, 0}
end

function ChangeState(s, n)
	waveState = s or 1
	timer = 0
	nextWaveState = n or 1
end

function Button(x, y, r, p)
	local button = CreateButton("w", "b", not(math.random(0, 10) == 10))
	button.MoveTo(x, y)
	button.setVar("timer", 0)
	button.sprite.rotation = r
	button.setVar("dmg", 5)
	button.setVar("inv", 2)
	button.setVar("play", not(p == false))
	
	local warn = CreateSprite("intro/white")
	warn.color = {1, 0, 0}
	warn.MoveTo(button.absx, button.absy)
	warn.Scale(10000, 3)
	warn.rotation = button.sprite.rotation
	warn.layer = "BelowBullet"
		
	if not(p == false) then Audio.PlaySound("bullet warning") end
		
	button.setVar("warn", warn)
	table.insert(buttons, button)
	
	return button
end

waveStates = {}

waveStates[1] = function()
	if (timer == 1) then
		foreGround = CreateSprite("bg", "Top")
		foreGround.MoveTo(Misc.cameraX + 320, Misc.cameraY + 240)
		Audio.Pause()
		Audio.PlaySound("click")
	elseif (timer >= 30) then
		Audio.Unpause()
		Audio.PlaySound("click")
		foreGround.Remove()
		foreGround = nil
		ChangeState(nextWaveState)
	end
end

waveStates[2] = function()
	if timer == 1 then
		left = CreateProjectile("px", -30, -30)
		right = CreateProjectile("px", 30, -30)
		Arena.ResizeImmediate(70, 80)
		Arena.Move(0, -40, false, true)
		noose = CreateProjectile("NooseGrey", 0, 530)
		noose.sprite.Scale(1.5, 1.5)
		noose.setVar("color", "g")
		noose.setVar("dmg", 5)
		noose.setVar("inv", 1.5)
		right.sprite.Scale(10, 10)
		right.setVar("color", "w")
		right.setVar("dmg", 1)
		right.setVar("inv", 0)
		left.sprite.Scale(10, 10)
		left.setVar("color", "w")
		left.setVar("dmg", 1)
		left.setVar("inv", 0)
		Encounter.Call("ChangeBGTo", "Sayori")
	end
	if timer <= 90 then
		noose.absy = 630 - math.sin(math.rad(timer))*350
	else
		noose.absy = noose.absy + 2
		right.y = right.y + 2
		left.y = left.y + 2
		Arena.Move(0, 2, false, true)
	end
	if timer == 80 then
		Audio.PlaySound("warning1")
	end
	if timer == 90 then
		noose.sprite.Set("NooseWhite")
		noose.setVar("color", "w")
	end
	if (timer >= 240) then
		ChangeState(1, 3)
		noose.Remove()
		moose = nil
		right.Remove()
		right = nil
		left.Remove()
		left = nil
	end
end

waveStates[3] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(80, 400)
		Arena.MoveTo(320, -200, false, true)
		Encounter.Call("ChangeBGTo", "Natsuki")
	end
	
	if (timer % 20 == 0 and timer < 300) then
		if (cupcakeO) then
			local cupcake = CreateProjectile("cupcake", -30, 500)
			cupcake.setVar("color", "w")
			cupcake.setVar("dmg", 3)
			cupcake.setVar("inv", 1)
			cupcake.setVar("dir", -1)
			table.insert(cupcakes, cupcake)
			
			local cupcake2 = CreateProjectile("cupcake", 30, 500)
			cupcake2.setVar("color", "w")
			cupcake2.setVar("dmg", 3)
			cupcake2.setVar("inv", 1)
			cupcake2.setVar("dir", -1)
			table.insert(cupcakes, cupcake2)
		else
			local cupcake = CreateProjectile("cupcake", 0, 500)
			cupcake.setVar("color", "w")
			cupcake.setVar("dmg", 3)
			cupcake.setVar("inv", 1)
			cupcake.setVar("dir", -1)
			table.insert(cupcakes, cupcake)
		end
		cupcakeO = not cupcakeO
	end
	
	for i=1, #cupcakes do
		local cupcake = cupcakes[i]
		local speed = (cupcake.absy <= -10 and 1 or 3)
		cupcake.sprite.y = cupcake.sprite.y + speed * cupcake.getVar("dir")
		if (cupcake.y <= -Arena.height/2) then
			cupcake.setVar("dir", 1)
		end
		if (cupcake.sprite.y >= 600) then
			cupcake.Remove()
		end
	
		local deltax = Player.x - cupcake.x
		local deltay = Player.y - cupcake.y
		local distance = math.sqrt((deltax * deltax) + (deltay * deltay))
		if distance < 100 then
			cupcake.sprite.color = {1-(distance/100), 192/255 + (distance/25500), 1-(distance/100)}
		else
			cupcake.sprite.color = {0, 192/255, 0}
		end
	end

	if Player.absy < 8 then Player.MoveToAbs(Player.absx, 8) end
	
	if (timer >= 900) then
		ChangeState(1, 4)
		for i=1, #cupcakes do
			cupcakes[i].Remove()
		end
		cupcakes = {}
	end
end

waveStates[4] = function()
	if (timer == 1) then
		--fakeBG = CreateSprite("FakeBG", "BelowArena")
		--fakeBG.MoveTo(320, 0)
		Arena.ResizeImmediate(40, 1500)
		Arena.MoveTo(320, -1200, false, true)
		Player.MoveTo(0, Arena.height/2 - 40, false)
		
		bigKnife = CreateProjectile("Knife3", 600, 760)
		bigKnife.sprite.Scale(8, 8)
		bigKnife.sprite.rotation = 180
		bigKnife.setVar("color", "w")
		bigKnife.setVar("dmg", 1000)
		
		OverrideRedMovement = true
		Player.sprite.color32 = {66, 252, 255}
		Encounter.Call("ChangeBGTo", "Yuri")
	end
	if (Player.absy <= 200) then
		--[[Arena.Move(0, 2, true, true)
		--fakeBG.y = math.min(fakeBG.y+2, fakeBG.height/2)
		--bigKnife.sprite.y = bigKnife.sprite.y + 2
		for i=1, #knives do
			knives[i].sprite.y = knives[i].sprite.y + 2
		end
		--]]
		Misc.cameraY = Misc.cameraY - 2
	end
	if (timer <= 45) then
		bigKnife.x = 600 - math.sin(math.rad(timer*2))*550
	elseif (timer == 60) then
		OverrideRedMovement = false
		Player.sprite.color = {1, 0, 0}
	elseif (timer > 80) then
		bigKnife.sprite.y = bigKnife.sprite.y - math.min((timer - 80) /30, 2)
		for i=1, #knives do
			knives[i].sprite.y = knives[i].sprite.y + 1
		end
	end
	
	if (timer % 30 == 0 and timer > 80) then
		local knife = CreateProjectile("Knife" .. math.random(1,3), Player.x, -3000)
		knife.absy = Misc.cameraY - 50
		knife.sprite.rotation = 90
		knife.setVar("color", "w")
		knife.setVar("dmg", 3)
		knife.setVar("inv", 0.1)
		table.insert(knives, knife)
	end
	
	if (Player.y <= -Arena.height/2+8) then
		ChangeState(1, 5)
		--fakeBG.Remove()
		--fakeBG = nil
		bigKnife.Remove()
		bigKnife = nil
		for i=1, #knives do
			knives[i].Remove()
		end
		knives = {}
	end
end

waveStates[5] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(100, 100)
		Arena.MoveTo(320, 300, false, true)
		Player.MoveTo(0, 0, false)
		pen = CreateProjectile("Monika/Pen", 70, 0)
		pen.sprite.Scale(1.5, 1.5)
		pen.sprite.color32 = {252, 166, 0}
		pen.setVar("color", "o")
		pen.setVar("dmg", 5)
		Misc.ResetCamera()
	end
	pen.sprite.x = pen.sprite.x - 8
	if (timer >= 40) then
		pen.Remove()
		pen = nil
		ChangeState(1, 6)
	end
	Encounter.Call("ChangeBGTo", "Monika")
end

waveStates[6] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(100, 100)
		Arena.MoveTo(320, 150, false, true)
		Player.MoveTo(0, 0, false)
		pen = CreateProjectile("Monika/Pen", 0, -70)
		pen.sprite.Scale(1.5, 1.5)
		pen.sprite.color32 = {66, 252, 255}
		pen.sprite.rotation = -90
		pen.setVar("color", "c")
		pen.setVar("dmg", 5)
	end
	pen.sprite.y = pen.sprite.y + 8
	if (timer >= 40) then
		pen.Remove()
		pen = nil
		ChangeState(1, 7)
	end
end

waveStates[7] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(150, 150)
		Player.MoveTo(200, -200, false)
	end
	if (timer % 10 == 0) then
		local butt = Button(1640, -75 + timer/1.5, 180)
		butt.sprite.Scale(-1, 1)
		Button(75 - timer/1.5, -1000, 90)
	end
	for i=1, #buttons do
		buttons[i].setVar("timer", buttons[i].getVar("timer") + 1)
		if (buttons[i].getVar("timer") == 10) then
			buttons[i].getVar("warn").Remove()
			buttons[i].setVar("warn", nil)
			Audio.PlaySound("Intense anime jump")
		else
			RotationBasedMovement(buttons[i].sprite, 40)
		end
	end
	if (timer >= 200) then
		for i=1, #buttons do
			if (not (buttons[i].getVar("warn") == nil)) then
				buttons[i].getVar("warn").Remove()
			end
			buttons[i].getVar("text").Remove()
			buttons[i].Remove()
		end
		buttons = {}
		ChangeState(1, 8)
	end
end

waveStates[8] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(150, 150)
		Player.MoveTo(-200, 200, false)
		butt1 = CreateButton("w", "b", not(math.random(0, 10) == 10))
		butt1.MoveTo(-200, 0)
		butt1.sprite.rotation = 90
		butt1.setVar("dmg", 5)
		butt1.setVar("inv", 2)
		butt2 = CreateButton("w", "b", not(math.random(0, 10) == 10))
		butt2.MoveTo(0, 200)
		butt2.sprite.rotation = 0
		butt2.setVar("dmg", 5)
		butt2.setVar("inv", 2)
	end
	butt1.x = -200 + math.sin(math.rad((timer-40) * 1.5)) * 250
	butt2.y = 200 - math.sin(math.rad((timer-40) * 1.5)) * 250
	if (timer >= 180) then
		butt1.Remove()
		butt1 = nil
		butt2.Remove()
		butt2 = nil
		ChangeState(1, 9)
	end
end

waveStates[9] = function()
	if (timer == 1) then
		Arena.ResizeImmediate(200, 200)
		Player.MoveTo(0, 0, false)
		OverrideRedMovement = true
		Player.sprite.color32 = {66, 252, 255}
		buttonSpeed = 20
		
		whiteness = CreateSprite("intro/white", "Top")
		whiteness.alpha = 0
		whiteness.Scale(640, 480)
		whiteness.MoveTo(320, 240)
	end
	if (timer == 30) then
		for i=1, 36 do
			local x = math.sin(math.rad(i*10)) * 800
			local y = math.cos(math.rad(i*10)) * 800
			local butt = Button(x, y, math.deg(math.atan2(y - Player.y, x - Player.x)) + 180, (i<=10 and true or false))
		end
		Audio.Pause()
	end
	if (timer == 40) then
		local txt = CreateText( {"[voice:Monika][noskip]Wait[w:8], what?[w:50] ", "[voice:Monika][noskip]NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO"}, {360, 400}, 100, "BelowPlayer", -1)
		txt.SetSpeechThingPositionAndSide("left")
		txt.SetAutoWaitTimeBetweenTexts(40)
		Audio.PlaySound("Encounter")
	end
	if (timer > 50 and timer < 140) then
		buttonSpeed = 8 - math.sin(math.rad(timer-50))*8
		whiteness.alpha = math.sin(math.rad(timer-50))
	end
	if (timer == 230) then
		whiteness.Remove()
		whiteness = nil
	end
	if (timer == 260) then
		for i=1, #buttons do
			buttons[i].sprite.rotation = buttons[i].sprite.rotation + math.random(80, 180) * (math.random(1,2) == 1 and -1 or 1)
			buttons[i].setVar("color", "g")
		end
		buttonSpeed = 10
		Audio.PlaySound("Bad Memory")
	end
	for i=1, #buttons do
		buttons[i].setVar("timer", buttons[i].getVar("timer") + 1)
		if (buttons[i].getVar("timer") == 30) then
			buttons[i].getVar("warn").Remove()
			buttons[i].setVar("warn", nil)
			if (buttons[i].getVar("play")) then Audio.PlaySound("Intense anime jump") end
		else
			RotationBasedMovement(buttons[i].sprite, buttonSpeed)
		end
	end
	if (timer >= 440) then
		for i=1, #buttons do
			if (not (buttons[i].getVar("warn") == nil)) then
				buttons[i].getVar("warn").Remove()
			end
			buttons[i].getVar("text").Remove()
			buttons[i].Remove()
		end
		buttons = {}
		State("ENEMYDIALOGUE")
	end
end

require "waveBasic"