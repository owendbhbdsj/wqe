
Encounter["wavetimer"] = math.huge

function Update()

end