
right = CreateProjectile("px", 30, -30)
right.sprite.Scale(10, 10)

left = CreateProjectile("px", -30, -30)
left.sprite.Scale(10, 10)

noose = CreateProjectile("NooseGrey", 0, 130)
noose.sprite.Scale(1.5, 1.5)
noose.ppcollision = true

blue = CreateProjectile("NooseBlueOver", 0, 130)
blue.sprite.Scale(1.5, 1.5)
blue.ppcollision = true
blue.sprite.SetParent(noose.sprite)
blue.sprite.MoveTo(1, -177)
blue.setVar("isBlue", true)

timer = 0
timerSPD = 1
Encounter["wavetimer"] = 3.5
Arena.ResizeImmediate(70, 80)
Arena.Move(0, -40, false, true)

function Update()
	timer = timer + 1
	if timer <= 90 then
		noose.absy = 630 - math.sin(math.rad(timer))*350
	else
		noose.absy = noose.absy + 2
		Arena.Move(0, 2, false, true)
		right.y = right.y + 2
		left.y = left.y + 2
	end
	if timer == 80 then
		Audio.PlaySound("warning1")
		blue.Remove()
	end
	if timer == 90 then
		noose.sprite.Set("NooseWhite")
		
		OnHit = function(bullet)
			if (bullet.getVar("isBlue") and isPlayerMoving) then
				PHurt(3, 0.5)
			elseif bullet == left and bullet == right then
				PHurt(1, 0)
			else
				PHurt(5)
			end
		end
	end
end

function OnHit(bullet)
	if (bullet.getVar("isBlue") == true and isPlayerMoving) then
		PHurt(3, 0.5)
	elseif bullet == left and bullet == right then
		PHurt(1, 0)
	end
end

require "waveBasic"