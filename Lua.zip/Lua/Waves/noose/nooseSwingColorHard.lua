

nooses = {}

timer = 0
isBlue = true
Encounter["wavetimer"] = 8
Arena.Resize(200, 50)
Arena.Move(0, -30, false, true)

function Update()
	timer = timer + 1
	if (timer % 20 == 0) then
		SummonNoose(isBlue)
		isBlue = not isBlue
	end
	
	for i=1, #nooses do
		local n = nooses[i]
		if (n.isactive) then
			n.sprite.rotation = n.sprite.rotation - 1
			n.sprite.Move(-0.5, 0)
			if (n.sprite.rotation == 280) then
				n.getVar("child").Remove()
				n.Remove()
			end
		end
	end
end

function OnHit(bullet)
	local c = bullet.getVar("color")
	if (c == "w") then
		PHurt(3, 1)
	elseif (c == "c") and isPlayerMoving then
		PHurt(3, 1)
	elseif (c == "o") and (not isPlayerMoving) then
		PHurt(3, 1)
	end
end

function SummonNoose(color) 
	local n = CreateProjectile("NooseGrey", 50, 130)
	n.sprite.Scale(1.5, 1.5)
	n.ppcollision = true
	n.setVar("color", "g")
	
	local c = CreateProjectile("Noose".. GetColor(color) .."Over", 0, 130)
	c.sprite.Scale(1.5, 1.5)
	c.ppcollision = true
	c.sprite.SetParent(n.sprite)
	c.sprite.MoveTo(1, -177)
	c.setVar("isBlue", color)
	c.setVar("color", (color and "c" or "o"))
	
	n.sprite.SetPivot(0.5, 1)
	n.sprite.SetAnchor(0.5, 1)
	n.sprite.rotation = 100
	n.setVar("child", c)
	n.sprite.MoveTo(370, 490)
	
	table.insert(nooses, n)
end

function GetColor(blue)
	if (blue) then
		return "Blue"
	else
		return "Orange"
	end
end


require "waveBasic"