
require "ButtonSummon"

buttons = {}

timer = 0
Encounter["wavetimer"] = 10
Arena.Resize(80, 80)

function Update()
	timer = timer + 1
	if (timer % 40 == 0) then
		button = CreateButton("w", "b", not(math.random(0, 10) == 10))
		local rand = math.random(1, 360)
		button.MoveTo(math.sin(math.rad(rand)) * 500, math.cos(math.rad(rand)) * 500)
		button.setVar("timer", 0)
		PointTo(button, Player.x, Player.y)
		
		local warn = CreateSprite("intro/white")
		warn.color = {1, 0, 0}
		warn.MoveTo(button.absx, button.absy)
		warn.Scale(10000, 3)
		warn.rotation = button.sprite.rotation
		warn.layer = "BelowBullet"
		
		Audio.PlaySound("bullet warning")
		
		button.setVar("warn", warn)
		table.insert(buttons, button)
	end
	
	for i=1, #buttons do
		buttons[i].setVar("timer", buttons[i].getVar("timer") + 1)
		if (buttons[i].getVar("timer") == 10) then
			buttons[i].getVar("warn").Remove()
			buttons[i].setVar("warn", nil)
			Audio.PlaySound("Intense anime jump")
		elseif (buttons[i].getVar("timer") > 10) then
			RotationBasedMovement(buttons[i].sprite, 15)
		end
	end
end

function OnHit(bullet)
	local c = bullet.getVar("color")
	if (c == "w") then
		PHurt(3, 1)
	elseif (c == "c") and isPlayerMoving then
		PHurt(3, 1)
	elseif (c == "o") and (not isPlayerMoving) then
		PHurt(3, 1)
	end
end

function EndingWave()
	for i=1, #buttons do
		if (not (buttons[i].getVar("warn") == nil)) then
			buttons[i].getVar("warn").Remove()
		end
	end
end

require "waveBasic"