
require "ButtonSummon"

buttons = {}

timer = 0
Encounter["wavetimer"] = 10
Arena.Resize(100, 200)

function Update()
	timer = timer + 1
	if (timer % 50 == 0) then
		local button = CreateButton(((math.random(0, 1) == 0) and "c" or "o"), "w", not(math.random(0, 10) == 10))
		button.MoveToAbs(320 - ((math.random(0,1) == 0) and -40 or 40), 500)
		table.insert(buttons, button)
	end
	
	for i=1, #buttons do
		local button = buttons[i]
		button.y = button.y - 1.5
		--button.x = math.sin(math.rad(timer * 2)) * 80
	end
end

function OnHit(bullet)
	local c = bullet.getVar("color")
	if (c == "w") then
		PHurt(5, 1)
	elseif (c == "c") and isPlayerMoving then
		PHurt(5, 1)
	elseif (c == "o") and (not isPlayerMoving) then
		PHurt(5, 1)
	end
end

--button = CreateButton("c", "w", false)
--button.MoveTo(0, 0)

require "waveBasic"