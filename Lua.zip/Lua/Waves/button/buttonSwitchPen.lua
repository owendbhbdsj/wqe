
require "ButtonSummon"

buttons = {}

timer = 0
Encounter["wavetimer"] = 10
Arena.Resize(80, 120)
Player.Move(50, 0)

function Update()
	timer = timer + 1
	for i=1, #buttons do
		local button = buttons[i]
		button.setVar("timer", button.getVar("timer") + 2)
		button.MoveTo( -120 + math.sin(math.rad(button.getVar("timer")))*80, button.y)
	end
	pen.MoveTo(math.sin(math.rad((timer - 90)*2)) * 70, 0)
end

function OnHit(bullet)
	local c = bullet.getVar("color")
	if (c == "w") then
		PHurt(5, 1)
	elseif (c == "c") and isPlayerMoving then
		PHurt(5, 1)
	elseif (c == "o") and (not isPlayerMoving) then
		PHurt(5, 1)
	end
end

function EndingWave()
	for i=1, #buttons do
		if (not (buttons[i].getVar("warn") == nil)) then
			buttons[i].getVar("warn").Remove()
		end
	end
end

for i=1, 20 do
	local button = CreateButton("w", "b", not(math.random(0, 10) == 10))
	button.MoveTo( 0,-Arena.height/2+(i-1)*23+10)
	button.setVar("timer", (i%2==0 and 0 or 180))
	table.insert(buttons, button)
end

pen = CreateProjectile("Monika/Pen", 1000, 1000)
pen.sprite.color32 = GetColor("c")
pen.setVar("color", "c")
pen.sprite.Scale(2, 2)

require "waveBasic"