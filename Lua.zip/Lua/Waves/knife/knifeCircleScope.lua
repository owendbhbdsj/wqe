
knives = {}
angle = 0
timer = 0
Encounter["wavetimer"] = 6.0
Arena.Resize(80, 80)

function Update()
	timer = timer + 1
	if (timer % 18 == 0) then
		angle = angle + 20
		SummonKnife(angle)
	end
	
	for i=1,#knives do
		local k = knives[i]
		if (k.isactive) then
			k.setVar("timer", k.getVar("timer") + 3)
			if (k.getVar("timer") <= 300) then
				RotationBasedMovement(k.sprite, math.sin(math.rad(k.getVar("timer"))))
			else
				RotationBasedMovement(k.sprite, 6)
				k.setVar("alpha", k.getVar("alpha") - 0.1)
				k.sprite.alpha = k.getVar("alpha")
				if (k.sprite.alpha <= 0) then
					k.Remove()
				end
			end
		end
	end
end

function OnHit()
	PHurt(3, 0.1)
end

function SummonKnife(a)
	local x = math.sin(math.rad(a)) * 100
	local y = math.cos(math.rad(a)) * 100
	local k = CreateProjectile("Knife" .. math.random(1,3), x, y)
	k.ppcollision = true
	PointTo(k, Player.x, Player.y)
	k.setVar("timer", 200)
	k.setVar("alpha", 4.5)
	table.insert(knives, k)
	return k
end


require "waveBasic"


