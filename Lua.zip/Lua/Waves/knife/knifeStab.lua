


knives = {}

timer = 0
Encounter["wavetimer"] = 10.0
Arena.Resize(250, 50)
--Arena.Move(0, -30, false, true)

function Update()
	timer = timer + 1
	if (timer % 30 == 0) then
		SummonKnife()
	end
	
	for i=1, #knives do
		local k = knives[i]
		if (k.isactive) then
			k.setVar("timer", k.getVar("timer") + 2)
			if (k.getVar("timer") <= 120) then
				k.sprite.MoveTo(k.sprite.x, -100 + math.sin(math.rad(k.getVar("timer"))) * 150)
			else
				k.sprite.Move(0, 10)
				k.setVar("alpha", k.getVar("alpha") - 0.1)
				k.sprite.alpha = k.getVar("alpha")
				if (k.sprite.alpha <= 0) then
					k.Remove()
				end
			end
		end
	end
end

function OnHit(bullet)
	if (bullet.sprite.alpha >= 0.5) then
		PHurt(3, 0.1)
	end
end

function SummonKnife()
	local k = CreateProjectile("Knife" .. math.random(1,3), Player.x, -1000)
	k.ppcollision = true
	k.sprite.Scale(1.5, 1.5)
	k.sprite.rotation = 90
	k.setVar("timer", 0)
	k.setVar("alpha", 2.5)
	table.insert(knives, k)
end

require "waveBasic"