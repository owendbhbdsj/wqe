

knives = {}

timer = 0
Arena.Resize(250, 50)
--Arena.Move(0, -30, false, true)

rand = math.random(100, 250)

Encounter["wavetimer"] = 2.5 + rand/60

function Update()
	timer = timer + 1
	if (timer % 30 == 0 and timer <= rand) then
		SummonKnife()
	end
	
	for i=1, #knives do
		local k = knives[i]
		if (k.isactive) then
			if (k.getVar("active")) then
				k.setVar("timer", k.getVar("timer") + 2)
				if (k.getVar("timer") <= 120) then
					k.sprite.MoveTo(k.sprite.x, k.getVar("base") + math.sin(math.rad(k.getVar("timer"))) * 150)
				else
					k.sprite.Move(0, 10)
					k.setVar("alpha", k.getVar("alpha") - 0.1)
					k.sprite.alpha = k.getVar("alpha")
					if (k.sprite.alpha <= 0) then
						k.Remove()
					end
				end
			end
		end
	end
	if (timer == (rand + 20)) then
		for i=1,#knives do
			if knives[i].isactive then
				knives[i].Remove()
			end
		end
		Arena.ResizeImmediate(99, 99)
		Player.MoveTo(-10, 0)
		local n = SummonKnife()
		n.MoveTo(0, -1000)
		n.sprite.Scale(9, 9)
		n.sprite.Set("Knife2")
		n.setVar("base", -200)
		n.setVar("big", true)
	end
end

function OnHit(bullet)
	if (bullet.sprite.alpha >= 0.5) then
		if ( not bullet.getVar("big") == true) then
			PHurt(3, 0.1)
		else
			if (Player.x <= -34 and Player.y >= 34) then
				bullet.setVar("active", false)
				bullet.sprite.alpha = 1
				bullet.y = -8
			else
				PHurt(9999, 0)
			end
		end
	end
end

function SummonKnife()
	local k = CreateProjectile("Knife" .. math.random(1,3), Player.x, -1000)
	k.ppcollision = true
	k.sprite.Scale(1.5, 1.5)
	k.sprite.rotation = 90
	k.setVar("timer", 0)
	k.setVar("base", -100)
	k.setVar("alpha", 2.5)
	k.setVar("active", true)
	k.sprite.layer = "BelowPlayer"
	table.insert(knives, k)
	return k
end

require "waveBasic"