
webs = {}
spiders = {}
cspiders = {}
currWeb = 0

function SpiderSetUp(l, w, d)
	for i=1, #webs do
		webs[i].Remove()
	end
	webs = {}
	
	Arena.Resize(w + 40, (l-1)*50 + 40)
	
	for i=1, l do
		local web = CreateSprite("intro/white")
		web.MoveTo(Arena.x, Arena.y+((i-1)*50)+ 20)
		web.Scale(w, 2)
		web.layer = "BelowPlayer"
		web.color32 = {213, 53, 217}
		table.insert(webs, web)
	end
	
	
	Player.sprite.color32 = {213, 53, 217}
	OverrideRedMovement = true
	currWeb = d
	Player.MoveToAbs(Player.absx, webs[currWeb].y, false)
end

oldEW = EndingWave

function EndingWave()
	oldEW()
	for i=1, #webs do
		webs[i].Remove()
	end
	webs = {}
end

function PPlayerManager()
	isPlayerMoving = false
	if (Input.Up == 1) then
		currWeb = math.min(currWeb+1, #webs)
		Player.MoveToAbs(Player.absx, webs[currWeb].y, false)
		isPlayerMoving = true
	end
	if (Input.Down == 1) then
		currWeb = math.max(currWeb-1, 1)
		Player.MoveToAbs(Player.absx, webs[currWeb].y, false)
		isPlayerMoving = true
	end
	if (Input.Left > 0) then
		Player.MoveTo(math.max(Player.x-2, -webs[1].xscale/2), Player.y, false)
		isPlayerMoving = true
	end
	if (Input.Right > 0) then
		Player.MoveTo(math.min(Player.x+2, webs[1].xscale/2), Player.y, false)
		isPlayerMoving = true
	end
end

function SummonSpider(l, o, s) -- l - lineID, o - oldal(side)(1 or -1), s - speed
	local spider = CreateProjectile("spider", 1000, 1000)
	spider.MoveToAbs(webs[l].x + o * (webs[l].xscale/2), webs[l].y)
	spider.setVar("dir", -o)
	spider.setVar("speed", s)
	spider.setVar("sin", 0)
	table.insert(spiders, spider)
end

function PSpiderManager()
	for i=1, #spiders do
		local spider = spiders[i]
			if (spider.isactive) then
			spider.setVar("sin", math.min(spider.getVar("sin") + 4, 90))
			--spider.Move(math.sin(math.rad(spider.getVar("sin"))) * spider.getVar("speed") * spider.getVar("dir"), 0)
			spider.Move(spider.getVar("speed") * spider.getVar("dir"), 0)
			if (math.abs(spider.x) > Arena.width/2) then
				spider.Remove()
				--spiders[i] = nil
			end
		end
	end
end

function SummonCeilingSpider(x, s)
	local spider = CreateProjectile("cspider", 1000, 1000)
	spider.MoveTo(x, Arena.height/2+8)
	spider.setVar("speed", s)
	spider.setVar("timer", 0)
	
	local w = CreateProjectile("intro/white", 1000, 1000)
	w.MoveTo(x, Arena.height/2+8)
	w.sprite.SetPivot(0.5, 1)
	w.sprite.SetAnchor(0.5, 1)
	w.sprite.Scale(2, 1)
	
	spider.setVar("web", w)
	table.insert(cspiders, spider)
end

function PCSpiderManager()
	for i=1, #cspiders do
		local spider = cspiders[i]
		if (spider.isactive) then
			spider.setVar("timer", spider.getVar("timer") + spider.getVar("speed"))
			if (spider.getVar("timer") < 60) then
				spider.MoveTo(spider.x, Arena.height/2+8-spider.getVar("timer")/3)
			elseif (spider.getVar("timer") > 100) then
				spider.MoveTo(spider.x, (Arena.height/2+8)-(Arena.height)*math.sin(math.rad(spider.getVar("timer")-100)))
			end
			spider.getVar("web").sprite.Scale(2, (Arena.height/2+6)-spider.y)
			if (spider.getVar("timer") >= 280) then
				spider.getVar("web").Remove()
				spider.setVar("web", nil)
				spider.Remove()
			end
		end
	end
end