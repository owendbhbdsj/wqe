
local self = {}

function self.Init()
	local anim = {}
	for i=0, 254 do
		anim[i+1] = "intro/VoidAssambled/frame_" .. self.format(i) .. "_delay-0.1s"
	end
	self.void1 = CreateSprite("intro/white" ,"introBG")
	self.void1.SetAnimation(anim , 0.1)
	self.void1.Scale(introScale, introScale)
	self.void1.MoveTo(50, 300)

	local anim2 = {}
	for i=0, 254 do
		anim2[i+1] = "intro/VoidAssambled2/frame_" .. self.format(i) .. "_delay-0.1s"
	end
	self.void2 = CreateSprite("intro/white" ,"introBG")
	self.void2.SetAnimation(anim , 0.1)
	self.void2.Scale(introScale, introScale)
	self.void2.MoveTo(560, 300)
end

function self.Remove()
	self.void1.Remove()
	self.void1 = nil
	self.void2.Remove()
	self.void2 = nil
end

function self.format(n)
	local s = tostring(n)
	for i=s:len(), 2 do
		s = "0" .. s
	end
	return s
end

return self