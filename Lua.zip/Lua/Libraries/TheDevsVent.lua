

my_words = {
	{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},{"[next]"},
	{"[waitall:3]Hmm?", "You're still trying to play again?", "Why?[w:20] It's useless.", "The game destroyed itself at the end,[w:6] remember?"} ,
	{"[w:20]. [w:20]. [w:20].[w:20] *sigh*","I wrote it so that it crashes every time you try to open it, ok?", "There is no way I can change that."},
	{"Fine,[w:15] fine,[w:15] I'll tell you how you can play again.", "In ModDev mode, in the Options menu, there is a button called \"Reset AlMighty\".", "If you press it, all permanent data from all of the mods you played so far, ...", "Including the overworld, will loose it's permanent data.", "Including my mod."},
	{"Haven't you pressed it yet?", "What, you have other mods to play with checkpoints and stuff?", "Then play those."},
	{"Trust me, there is nothing left in this mod that could exite you, or whatever.", "There are no alternative attacks and such."},
	{"Why are you trying so desperately to go back?", "I already told you that there is nothing interesting here."},
	{"What?", "Are you curious about my lines?", "Look.[w:20]\nThere are people who know me[w:6], ok?", "And they aren't interested in me.", "Quite the contrary, to say the least.", "Why would you be?[w:30]\nIt's pointless."},
	{"[waitall:3]ARE YOU THIS RETARDED?", "I'VE ALREADY TOLD YOU!\n[w:20]I'M [w:20]NOT [w:20]WORTH [w:20]VASTING [w:20]TIME [w:20]WITH!", "Is this so hard to understand?", "[w:20]. [w:20]. [w:20]. ", "Sorry for shouting [w:5]. [w:5]. [w:5].\nAnd for calling you retarded.", "I-I didn't mean to."},
	{". . .", "*sigh*", "I'm sorry for this outburst.", "I promise it won't happen again."},
	{"[waitall:2]Sooooo[w:6],[waitall:1] listen[w:10], I got to go now.", "Do what you want[w:6], but I can't stay any longer.", "So[w:6], I guess this is goodbye.", "I'm glad for this short chat.", "Or, rather, listening to my monologe.", "See you sometime!"},
	{"[novoice][color:000000][w:9999999]"}
}