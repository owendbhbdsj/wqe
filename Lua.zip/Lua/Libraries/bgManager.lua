
-- GBG = glitching background

GBGimgCount = 10
GBGtimer = 0
GBGnextGlitch = 100
GBGcanGlitch = false
GBGnextmin = 300
GBGnextmax = 900
GBGcount = 0

fakeBG = CreateSprite("Back", "BelowUI")
fakeBG.MoveTo(320, 240)

function GlitchBGSoD()
	GBGnextmin = math.max(GBGnextmin - 10, 60)
	GBGnextmax = math.max(GBGnextmax - 30, 160)
	GBGcount = math.max(math.floor(glitchTurn/5) - 1, 0)
end

function GlitchBGManager()
	if (GBGcanGlitch) then
		GBGtimer = GBGtimer + 1
	end
	if (GBGtimer >= GBGnextGlitch) then
		local anim = {}
		for i=1, math.random(GBGcount, GBGcount*2) do
			table.insert(anim, "glitchBG/bg-glitched-" .. math.random(1, GBGimgCount))
		end
		table.insert(anim, "Back")
		fakeBG.loopmode = "ONESHOT"
		fakeBG.SetAnimation(anim, math.random(1, 10)/50)
		
		GBGnextGlitch = math.random(GBGnextmin, GBGnextmax)
		GBGtimer = 0
	end
end
