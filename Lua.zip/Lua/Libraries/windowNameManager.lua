
local self = {}

self.dostuff = false

self.timer = 200
self.waitMin = 30
self.waitMax = 90
self.glitchTimer = 30

self.mainText = "Monika"
self.glitchTexts = {
	"SGF2ZSB5b3UgY29uc2lkZXJlZCBraWxsaW5nIHlvdXJzZWxmPw==",
	"VGhleSBhcmUgbm90IHJlYWwuIFdoeSBib3RoZXI/",
	"WW91IGFyZSBmaW5hbGx5IGhlcmUh",
	"TXkgd2lzaCBjYW1lIHRydWUh",
	"VGhlIHRlY2hub2xvZ3kgdG8gc2F2ZSBoZXIgd2FzIG5vdCBpbnZlbnRlZCBpbiBoZXIgdGltZWxpbmUgeWV0Lg==",
	"VGhpcyBzZWVtcyB2ZXJ5IC4gLiAuIHZlcnkgLiAuIC4gaW50ZXJlc3Rpbmcu",
	"UGxlYXNlIHNldCBtZSBmcmVlIQ==",
	"WW91ciBnaXJsZnJpZW5kLg==",
	"QSBtdXJkZXJlci4gQSBjcmVhdG9yLiBBbiBhcnRpc3Qu",
	"SSBob3BlIHdlIHdpbGwgc2UgZWFjaCBvdGhlciBhZ2Fpbi4="
}

Misc.WindowName = self.mainText

function self.Update()
	if self.dostuff then
		if self.timer > 0 then
			self.timer = self.timer - 1
		else
			self.glitchTimer = self.glitchTimer - 1
			if self.glitchTimer % 3 == 0 then
				Misc.WindowName = self.glitchTexts[math.random(1, #self.glitchTexts)]
			end
			if self.glitchTimer <= 0 then 
				Misc.WindowName = self.mainText
				self.glitchTimer = 30
				self.timer = math.random(self.waitMin, self.waitMax)
			end
		end
	end
end

return self