
function PHurt(dmg, inv)
	if (not Encounter["isFGO"]) then
		if (Player.hp - dmg <= 0 and (not Player.ishurting)) then
			SetAlMightyGlobal("MonikaLastRun", "death")
			EndingWave()
			Encounter.Call("FakeGameOver")
		else
			Player.hurt(dmg, (inv or 3)*Encounter["devider"]/Encounter["numerator"])
		end
	end
end

RU = Update
isPlayerMoving = false
lastX = Player.x
lastY = Player.y

Player.SetControlOverride(true)

function Update()
	local speed = Encounter["speed"]
	for i=1, speed[(Encounter["speedTimer"] % #speed) + 1] do
		if (not OverrideRedMovement) then
			if (Input.Up > 0) then
				Player.Move(0, (Input.Cancel >=1 and 1 or 2), false)
				isPlayerMoving = true
			end
			if (Input.Down > 0) then
				Player.Move(0, -1*(Input.Cancel >=1 and 1 or 2), false)
				isPlayerMoving = true
			end
			if (Input.Left > 0) then
				Player.Move(-1*(Input.Cancel >=1 and 1 or 2), 0, false)
				isPlayerMoving = true
			end
			if (Input.Right > 0) then
				Player.Move((Input.Cancel >=1 and 1 or 2), 0, false)
				isPlayerMoving = true
			end
			
			if (Player.x > Arena.width/2-8) then
				Player.MoveTo(Arena.width/2-8, Player.y, false)
			elseif (Player.x < -Arena.width/2+8) then
				Player.MoveTo(-Arena.width/2+8, Player.y, false)
			end
			if (Player.y > Arena.height/2-8) then
				Player.MoveTo(Player.x, Arena.height/2-8, false)
			elseif (Player.y < -Arena.height/2+8) then
				Player.MoveTo(Player.x, -Arena.height/2+8, false)
			end
			if lastX == Player.x and lastY == Player.y then
				isPlayerMoving = false
			else
				isPlayerMoving = true
			end
			lastY = Player.y
			lastX = Player.x
		end
		RU()
	end
end

Encounter["wavetimer"] = Encounter["wavetimer"] * Encounter["devider"]/Encounter["numerator"]

function RotationBasedMovement(sprite, speed)
	local rotation = sprite.rotation
	x = math.cos(math.rad(rotation)) * speed
	y = math.sin(math.rad(rotation)) * speed
	sprite.Move(x, y)
end

function PointTo(obj, x, y)
	local deltay = obj.y - y
	local deltax = obj.x - x
	obj.sprite.rotation = math.deg(math.atan2(deltay, deltax)) + 180
end

function SelectProjectileAction( list, Function)
	local index = 0
	for i=1, #list do
		index = index + 1
		if index <= #list then
			local bullet = list[index]
			if bullet.isactive then
				Function(bullet)
			else
				table.remove(list, index)
				index = index - 1
			end
		end
	end
end

if (Encounter["wavetimer"] == 0) then
	Encounter["wavetimer"] = 4
end

if (EndingWave == nil) then
	function EndingWave()
	
	end
end
