


CreateLayer("PlayerAbove", "Top", true)

CreateLayer("introBG", "Top")
CreateLayer("introMonika", "introBG")
CreateLayer("introDialogue", "introMonika")
CreateLayer("onTopOfAll", "introDialogue")
CreateLayer("MonikaHand", "BelowArena", true)

void = require "SpaceClassroomBG"

function introStart()
	--AlMightySetUp()
	SwapSong("Just Monika")
	nextwaves = {"w8"}
	State("DEFENDING")
	
	introBG = CreateSprite("intro/Foreground",  "introMonika")
	introScale = 640/introBG.width + 0.1
	introBG.Scale(introScale, introScale)
	introBG.MoveTo(320, 240)
	
	blackness = CreateSprite("intro/black", "introBG")
	blackness.Scale(640, 480)
	blackness.MoveTo(320, 240)

	void.Init()
	
	textBox = CreateSprite("intro/textBox",  "introDialogue")
	textBox.Scale(introScale, introScale)
	textBox.MoveTo(320, 80)
	
	text = CreateText({"Hiii"}, {90, (146*introScale)/2 + 45}, 460, "introDialogue", (146*introScale))
	text.progressmode = "manual"
	text.SetVoice("none")
	text.SetText(introDialogue)
	text.HideBubble()
end

function introEnd()
	ftimer = 0
	whiteFade = CreateSprite("intro/white",  "onTopOfAll")
	whiteFade.Scale(640, 480)
	whiteFade.MoveTo(320, 240)
	Audio.Stop()
end

function battleStart()
	enemies[1]["currentdialogue"] = nil
	State("ENEMYDIALOGUE")
	wavetimer = 6.0
end

function introUpdate()
	if (whiteFade ~= nil) then
		ftimer = ftimer + 1
		whiteFade.alpha = math.sin(math.rad(ftimer))
		if (ftimer == 90) then
			whiteFadeFullMark()
		end
		if (ftimer >= 180) then
			whiteFade.Remove()
			whiteFade = nil
			battleStart()
		end
	end
end

whiteFadeFullMark = function()
	introBG.Remove()
	introBG = nil
	
	blackness.Remove()
	blackness = nil
	
	textBox.Remove()
	textBox = nil
	
	text.DestroyText()
	text = nil

	void.Remove()
	
	toggleMonika(90, true)
end

function SwapSong(song)
	Audio.LoadFile(song)
end