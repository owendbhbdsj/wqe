
Amy = {}

BGAnimFuncs.start.Amy = function()

end

BGAnimFuncs.update.Amy = function()

end

BGAnimFuncs.fin.Amy = function()

end