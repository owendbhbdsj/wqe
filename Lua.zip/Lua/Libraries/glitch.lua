
glitches = {}
glitchLifeSpans = {}
glitchCache = {}
gtimer = 0
gwait = 10
gwaitmin = 200
gwaitmax = 400
gcount = 0

glitchTurn = currAttack

function GlitchSoD()
	glitchTurn = glitchTurn + 1
	gwaitmin = math.max(gwaitmin - 10, 8)
	gwaitmax = math.max(gwaitmax - 20, 18)
	gcount = math.floor(glitchTurn/8)
end


function GlitchManager()
	gtimer = gtimer + 1
	if (gtimer >= gwait) then
		for i=1, gcount do
			SummonGlitch()
		end
		gtimer = 0
		gwait = math.random(gwaitmin, gwaitmax)
	end
	
	for i=1, #glitches do
		if (i<=#glitches) then
			local g = glitches[i]
			glitchLifeSpans[i] = glitchLifeSpans[i] - 1
			if (glitchLifeSpans[i] <= 0) then
				g.MoveTo(1000, 1000)
				table.remove(glitches, i)
				table.remove(glitchLifeSpans, i)
				table.insert(glitchCache, g)
			end
			if (not (Wave == nil)) then
				if(g.layer == "Top" and #Wave > 0) then
					g.layer = "BelowArena"
				elseif (g.layer == "BelowArena" and #Wave == 0) then
					g.layer = "Top"
				end
			end
		end
	end
end

function SummonGlitch()
	local g = "something"
	if (#glitchCache == 0) then
		g = CreateSprite("intro/white",  "Top")
	else
		g = glitchCache[1]
		table.remove(glitchCache, 1)
	end
	
	g.Scale(math.random(5, 100), math.random(5, 100))
	g.MoveTo(math.random(0, 640), math.random(0, 480))
	g.color32 = {math.random(0, 255), math.random(0, 255), math.random(0, 255), math.random(0, 150)}
	table.insert(glitches, g)
	table.insert(glitchLifeSpans, math.random(5, 20))
end