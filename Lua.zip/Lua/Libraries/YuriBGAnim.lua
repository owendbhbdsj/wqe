
Yuri = {}

BGAnimFuncs.start.Yuri = function()
	Yuri[1] = CreateSprite("SpecialBG/Yuri", "BelowUI")
	Yuri[1].alpha = 0

	Yuri[2] = CreateSprite("SpecialBG/YuriC", "BelowUI")
	Yuri[2].alpha = 0.6
end

BGAnimFuncs.update.Yuri = function()
	YuriSpeed = 0.6 / ((wavetimer*devider/numerator-2) * 60)
	Yuri[2].alpha = math.max(Yuri[2].alpha - YuriSpeed, 0)
	Yuri[1].alpha = math.min(Yuri[1].alpha + YuriSpeed, 0.6)
end

BGAnimFuncs.fin.Yuri = function()
	Yuri[1].Remove()
	Yuri[2].Remove()

	Yuri = {}
end