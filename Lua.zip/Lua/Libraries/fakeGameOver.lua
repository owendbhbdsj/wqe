
isFGO = false
FGOtimer = 0
canFGOProgress = false
FGOTexts = {Sayori	= { "[effect:shake,0.5][w:30]No[w:5], please!", 
						"[effect:shake,0.55]I [w:10]... I'm not worthless.", 
						"[effect:shake,0.6]I'm sure that I [w:2]. [w:2]. [w:2].", 
						"[effect:shake,0.65]. . . I have a purpose.", 
						"[effect:shake,0.7][w:20][waitall:2]Right?", 
						"[effect:shake,0.75][w:10]. [w:10]. [w:10]. [w:10]Heh.", 
						"[effect:shake,0.8]What's the point in lying to myself[w:5], anyway?" },
			Yuri	= {	"[w:30]Why?", 
						"[w:15][func:bloodyScreenAlpha,{0.1,10}][w:15][effect:shake,0.5]Even if I know this is wrong.",
						"[w:8][effect:shake,0.55]But why does it feel [w:3]. [w:3]. [w:3].",
						"[w:3]. [w:3]. [w:3]. [w:3][effect:shake,0.65][func:bloodyScreenAlpha,{0.15,6}][waitall:2]so good?",
						"So [w:3]. [w:3]. [w:3]. [w:3] [func:bloodyScreenAlpha,{0.2,6}]relaxing and [w:8][waitall:3][speed:2]exhilarating!",
						"[func:bloodyScreenAlpha,{0.5,1.5}]Hahaha[waitall:3]hahahaha[waitall:1] [w:3]. [w:3]. [w:3]. [w:3] ",
						"Huh [w:3]. [w:3]. [w:3]. [w:3][func:bloodyScreenAlpha,{0,1.5}]I'm such a freak[w:10], aren't I?"
						},
			Natsuki	= {	"[w:30]Oh[w:5], no!",
						"Oh geez!",
						"[waitall:2]What am I gonna do?",
						"I didn't want this to happen [w:4]. [w:4]. [w:4].",
						"[effect:shake,0.6]I [w:3]. [w:3]. [w:3]. [w:3]just [w:3]. [w:3]. [w:3].",
						"[w:13]. [w:3]. [w:3]. [w:3]*sigh*",
						"[waitall:2]There is no escape.",
						"Not even lying can get me out of this.",
						"[effect:shake,0.4][waitall:3]My parents are gonna kill me."},
			Monika	= {	"[w:30]How [w:3]are we here in the first place?",
						"What makes us [w:8]what we [w:4]. [w:4]. [w:4]. [w:4]are?",
						"Do we really [w:3]. [w:3]. [w:3]. [w:3]exist?",
						"Are the stuff we learn in physics, chemistry and biology really true?",
						"I mean[w:8], from what we [waitall:2]really[waitall:1] know, we could be[w:4]. [w:4]. [w:4].",
						"I don't know. [w:12]Some video game characters or something along those lines."},
			Amy 	= {"[effect:shake,1][waitall:3]You dirty hacker!"},
			None	= {}
		}

FGOTextNr = {None = 1, Natsuki = 2, Yuri = 3, Sayori = 4, Monika = 5, Amy = 6}

NewAudio.CreateChannel("FakeGOGlitch")
NewAudio.SetVolume("FakeGOGlitch", 0.7)
NewAudio.CreateChannel("FakeGOStatic")
NewAudio.SetVolume("FakeGOStatic", 0.7)

SetAlMightyGlobal("MonikaDeathTexts", 0)

function FakeGameOver()
	FGOtimer = 0
	isFGO = true
	
	Misc.StopShake()
	Misc.MoveCameraTo( 0, 0)

	Audio.Stop()
	Audio.PlaySound("hurtsound")
	
	FGOBG = CreateSprite("black", "Top") --Fake Game Over BackGround
	FGOBG.Scale(640, 480)
	FGOBG.MoveTo(320, 240)
	
	FGOSoul = CreateSprite("ut-heart", "Top")
	FGOSoul.MoveTo(Player.absx - Misc.cameraX,  Player.absy - Misc.cameraY)
	FGOSoul.color = Player.sprite.color
		
	wavetimer = math.huge
	nextwaves = {"w8"}
	State("DEFENDING")
	
	SetAlMightyGlobal("MonikaLastRun", "death")
	
	Wave[1].Call("EndingWave")
	canFGOProgress = true
end

function FakeGameOverManager()
	bloodyScreen.Update()
	if (isFGO and canFGOProgress) then
		FGOtimer = FGOtimer + 1
		if ((FGOtimer % 20 == 0) and (FGOtimer >= 140)) then
			NewAudio.PlaySound("FakeGOGlitch", "Modem" .. math.random(1,6), false)
		end
		if (FGOtimer == 60) then
			Audio.PlaySound("heartbeatbreaker")
			FGOSoul.Set("ut-heart-broken")
		end
		if (FGOtimer == 120) then
			_processFGO120()
		end
		if (FGOtimer == 140) then
			_processFGO140()
		end
		if (FGOtimer >= 340) then
			isFGO = false
			_processFGO340()
		end
	end
end

function _processFGO120()
	canFGOProgress = false
	FGOSoul.Remove()
	FGOSoul = nil
	local txt = ( (not GetAlMightyGlobal("MonikaDidDie" .. currBG) ) and {table.unpack(FGOTexts[currBG])} or {}) or {}
	SetAlMightyGlobal("MonikaDidDie" .. currBG, true)
	for i=1, #txt do
		txt[i] = "[noskip][novoice][font:uidialog]" .. txt[i]
	end
	txt[#txt + 1] = "[func:DeleteFGOText][func:SetVar,{canFGOProgress,true}]"
	FGOText = CreateText(txt, {320, 240}, 400, "Top", -1)
	FGOText.progressmode = "manual"
	FGOText.HideBubble()
	FGOText.MoveTo(120, 230)
end

function _processFGO140()
	FGOScare = CreateSprite("static/1", "Top")
	FGOScare.Scale(640/FGOScare.width, 480/FGOScare.height)
	FGOScare.MoveTo(320, 240)
	FGOScare.loopmode = "ONESHOTEMPTY"
	FGOScare.alpha = 0.95
	local anim = {}
	for i=1, 48 do
		table.insert(anim, "static/" .. i)
	end
	FGOScare.SetAnimation(anim, 0.07)
	NewAudio.PlaySound("FakeGOStatic", "static", true, 1)
end 

function _processFGO340() 
	FGOBG.Remove()
	FGOBG = nil
	FGOScare.Remove()
	FGOScare = nil

	StartVariableSet()
	AlMightySetUp()

	bloodyScreenAlpha(0)
	
	NewAudio.Stop("FakeGOGlitch")
	NewAudio.Stop("FakeGOStatic")	
end

function StartVariableSet()
	State("ACTIONSELECT")
	Player.hp = Player.maxhp
	currAttack = 0
	Inventory.SetInventory({"TestDog1", "TestDog2", "TestDog3", "TestDog4"})
	wavetimer = 4.0
	enemies[1]["hp"] = 300
	enemies[1]["hitMultReq"] = 1
	enemies[1]["currTalk"] = 0
	testDogCurr = 0
	mState = 1
	numerator = 100
	ChangeSpeed(numerator, devider)
	mad = false

	SetAlMightyGlobal("SpiderCyder Count", 0)
	
	gtimer = 0
	gwait = 10
	gwaitmin = 200
	gwaitmax = 400
	gcount = 0
end

function SetVar(n, v)
	_G[n] = v
end

function DeleteFGOText()
	FGOText.DestroyText()
end

bloodyScreen = {}
bloodyScreen.sprite = CreateSprite("Blood", "Top")
bloodyScreen.sprite.MoveTo(320, 240)

bloodyScreen.speed = 0
bloodyScreen.timer = 91
bloodyScreen.goal = 0
bloodyScreen.start = 0

bloodyScreen.Update = function()
	if (bloodyScreen.timer * bloodyScreen.speed <= 90) then
		bloodyScreen.timer = bloodyScreen.timer + 1
		bloodyScreen.sprite.alpha = bloodyScreen.start + math.sin(math.rad(bloodyScreen.timer * bloodyScreen.speed)) * (bloodyScreen.goal - bloodyScreen.start)
	else
		bloodyScreen.sprite.alpha = bloodyScreen.goal
	end
end

function bloodyScreenAlpha(a, s, st)
	bloodyScreen.start = st or bloodyScreen.sprite.alpha
	bloodyScreen.speed = s or 91
	bloodyScreen.timer = 0
	bloodyScreen.goal = a
	bloodyScreen.sprite.SendToTop()
end

function Exponent(n, e)
	if e == 0 then
		n = 1
	else
		for i=1, e-1 do
			n = n * n
		end
	end
	return n
end

function revertTable(t)
	local tc = {}
	for i=1, #t do
		tc[#t-i+1] = t[i]
	end
	return tc
end

function DecToTableOfBinary(n)
	if n == 0 then
		return {0}
	else
		local t = {}
		while n ~= 0 do
			t[#t+1] = n % 2
			n = math.floor(n/2)
		end
		return revertTable(t)
	end
end

function TableOfBinaryToDec(t)
	local n = 0
	local i = 0
	t = revertTable(t)
	while i < #t do
		local a = t[i+1] or 0
		n = n + a * Exponent(2, i)
		i = i + 1
	end
	return n
end

bloodyScreenAlpha(0)