
Sayori = {}

BGAnimFuncs.start.Sayori = function()
	Sayori[1] = CreateSprite("SpecialBG/Sayori", "BelowUI")
	Sayori[1].alpha = 0.3

	Sayori[2] = CreateSprite("SpecialBG/Sayori", "BelowUI")
	Sayori[2].alpha = 0.3
end

BGAnimFuncs.update.Sayori = function()
	Sayori[1].x = 320 + math.sin(math.rad(SBGtimer*1.5))*3
	Sayori[2].x = 320 + math.sin(math.rad(SBGtimer-180*1.5))*3

	Sayori[1].y = 240 + math.sin(math.rad(SBGtimer *0.8)) * 5
	Sayori[2].y = 240 + math.sin(math.rad(SBGtimer *1)) * 5
end

BGAnimFuncs.fin.Sayori = function()
	Sayori[1].Remove()
	Sayori[2].Remove()
	Sayori = {}
end