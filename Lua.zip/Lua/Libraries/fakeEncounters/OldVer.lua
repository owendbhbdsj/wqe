

nextwaves = {"incompetence"}
--nextwaves = {"UIOverride"}
wavetimer = math.huge
arenasize = {200, 200}
enemies = {"jevilika"}
enemypositions = {{0, 5}}
encountertext = "LET THE GAMES BEGIN!"
autolinebreak = true

timer = 0

function EncounterStarting()
	nextwaves = {"incompetence"}
	State("DEFENDING")
end

function Update()

end

function IntroUpdate()
	if isIntro then
		if timer % 40 == 0 then
			skipIcon.alpha = (skipIcon.alpha == 1 and 0 or 1)
		end
		if (Input.Menu == 1) then
			fade.StartFade(0, 0, 0)
			enemies[1].Call("Transformation", true)
		end
	end
end

function DefenseEnding()
	if not isIntro then
		encountertext = enemies[1]["comments"][math.random(1, #enemies[1]["comments"])]
	end
end

function EnemyDialogueStarting()
	if enemies[1]["currentdialogue"] == nil then
		nextwaves = {"Jevilka/BoysNGirls"}
		enemies[1]["currentdialogue"] = {"Dialogue"}
	end
	local text = {}
	for i=1, #enemies[1]["currentdialogue"] do
		text[i] = "[effect:none]" .. enemies[1]["currentdialogue"][i]
	end
	enemies[1]["currentdialogue"] = text
end