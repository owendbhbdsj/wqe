
-- A basic encounter script skeleton you can copy and modify for your own creations.

-- music = "shine_on_you_crazy_diamond" --Either OGG or WAV. Extension is added automatically. Uncomment for custom music.
encountertext = "It's just Monika.[func:RealComments]" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}
autolinebreak = true
playerskipdocommand = true
flee = false
unescape = true
deathtext = {"[noskip]Well, this was fun.", "But looks like I could beat you in your own game.", "See you soon :)."}

fs = true
currAttack = 0 -- Should be 0
Inventory.AddCustomItems({"TestDog1", "TestDog2", "TestDog3", "TestDog4", "Spider Cider"}, {0, 0, 0, 0, 3})
Inventory.SetInventory({"TestDog1", "TestDog2", "TestDog3", "TestDog4"})
mState = 1
AccTimer = 0

testDogDial = { {"You look inside your inventory.", 'All you can see is a bunch of outdated items, all labeled "TestDog".', "You take one and eat it.\nEven tho it literally has no texture,[w:20] it tastes good.", "[health:5]You recovered 5 HP."}, 
				{"You take one more TestDog.[w:10]\n[health:5]You recovered 5 HP."}, 
				{"You take another TestDog.[w:10]\n[health:5]You recovered 5 HP.", "Looks like you start to run low on the stuff,[w:5] don't you think?"},
				{"You ate your last TestDog.[w:10]\n[health:5][func:SpiderCider]You recovered 5 HP."}}
testDogCurr = 0

enemies = {"monika.chr"}

enemypositions = {
{0, 5}
}

numerator = 100
devider = 100
speed = {}
speedTimer = 0

SBGtimer = 0

NewAudio.CreateChannel("Amy")
SetAlMightyGlobal("SpiderCyder Count", 0)

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
    if windows then 
		WNM = require "windowNameManager"
	end
	require "Libraries/intro"
	require "Libraries/glitch"
	require "MonikaAnim"
	require "wavesspeech"
	require "allMightys"
	require "fakeGameOver"
	require "bgManager"
	
	AlMightySetUp()
	Player.SetAttackAnim({"nothing", "nothing", "nothing", "nothing", "nothing"}, 0.2)
	
	Player.name = "MC"
	SetPPCollision(true)
	
	ChangeSpeed(numerator, devider)
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
    -- If the monster's text has not be set, use one of the default text the monster uses.

	if (enemies[1]["currentdialogue"] == nil) then
		currAttack = currAttack + 1
		enemies[1]["currentdialogue"] = possible_dialogue[mState][math.min(currAttack, #possible_dialogue[mState])]
		if (mState == 1) then
			nextwaves = {possible_attacks[math.min(currAttack, #possible_attacks)]}
		elseif (mState == 2) then
			nextwaves = {"nothing"}
		end
		GlitchSoD()
		GlitchBGSoD()
	end
	
	if (safe and ((currAttack > 4 and mState == 1) or mState == 2)) then
		nextwaves = {"forSafeModePussies"}
	end

	local dial = enemies[1]["currentdialogue"]
	if type(dial) == "table" then
		enemies[1]["currentdialogue"] = {table.unpack(dial)}
	else
		enemies[1]["currentdialogue"] = {dial}
	end
	
	if (not(enemies[1]["currentdialogue"][1] == nil)) then
		for i=1, #enemies[1]["currentdialogue"] do
			enemies[1]["currentdialogue"][i] = "[effect:none][voice:Monika]" .. enemies[1]["currentdialogue"][i]
		end
		--enemies[1].Call("OverlayEnemyDialogue")
	end
	
	Player.hp = Player.hp
	if (hit ~= nil) then
		hit.Remove()
		hit = nil
	end
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- The wavetype is set in bullet_testing_poseur's act commands.
    --nextwaves = { possible_attacks[math.random(#possible_attacks)] }
	toggleMonika(4, false)
	GBGcanGlitch = false
	ChangeBGTo(GetAttackFamily(nextwaves[1]))
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
	toggleMonika(2, true)
	Player.sprite.color32 = {255, 0, 0}
	GBGcanGlitch = true
	ChangeBGTo("None")
	if enemies[1]["currTalk"] == 0 then
		MonikaExpression(1)
	end
end

function HandleSpare()
	if (not enemies[1]["canspare"]) then
		BattleDialog({"This isn't an option [w:5]. [w:5]. [w:5].\nYet."})
	end
end

function EnteringState(newstate, oldstate)
	if oldstate == "ENEMYDIALOGUE" then
		enemies[1]["currentdialogue"] = nil
	end
	if (canAcc) then
		Accident()
	end
end

function HandleItem(ItemID)
    if (not (string.find(ItemID, "TESTDOG", 1) == nil)) then
		testDogCurr = testDogCurr + 1
		BattleDialog(testDogDial[math.min(testDogCurr, #testDogDial)])
	elseif (ItemID == "SPIDER CIDER") then
		SetAlMightyGlobal("SpiderCyder Count", GetAlMightyGlobal("SpiderCyder Count") + 1)
		BattleDialog({"[noskip]You drank the Spider Cider.\n" .. spider_spell[math.random(1, #spider_spell)]})
		enemies[1]["currentdialogue"] = spider_speech[math.min(GetAlMightyGlobal("SpiderCyder Count"), #spider_speech)]
		nextwaves = {spider_attacks[math.random(1, #spider_attacks)]}
	end
end

function Update()
	
	MonikaAnimManager()
	FakeGameOverManager()
	introUpdate()
	if windows then
		WNM.Update()
	end

	if (not safe) then
		GlitchManager()
		GlitchBGManager()
	end
	
	if (Input.GetKey("Escape") == 1) then
		if (GetAlMightyGlobal("MonikaLastRun") ~= "death" and GetAlMightyGlobal("MonikaLastRun") ~= "win" and GetAlMightyGlobal("MonikaLastRun") ~= "none") then
			DEBUG("The player is a coward! " .. GetAlMightyGlobal("MonikaLastRun"))
			SetAlMightyGlobal("MonikaLastRun", "quit")
		end
		State("DONE")
	end

	if (canAcc) then
		AccTimer = AccTimer + 1
		if (AccTimer == 40) then
			Accident()
		end
	end
end

function RealComments()
	enemies[1]["comments"] = {"Smells like nothing.", "Monika starts to enjoy this.", "The entire world is a mess.", 
								"Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. Just Monika. "
								}
	canAcc = true
end

function SpiderCider()
	Inventory.SetItem(1, "Spider Cider")
end

TextFunc = {}

TextFunc[1] = string.lower
TextFunc[2] = string.upper

function makeString(l)
	if l < 1 then return nil end -- Check for l < 1
	local s = "" -- Start string
	for i = 1, l do
		s = s .. TextFunc[math.random(1, #TextFunc)](string.char(math.random(65, 90))) -- Generate random number from 65 to 90, turn it into character and add to string
	end
	return s -- Return string
end

function ChangeSpeed(n, d)
	speedTimer = 0
	local remnum = n
	speed = {}
	for i=1, d do
		table.insert(speed, 0)
	end
	while remnum >= d do
		remnum = remnum - d
		for i=1, d do
			speed[i] = speed[i] + 1
		end
	end
	local dist = d/remnum
	for i=1, d/dist do
		speed[math.floor(i*dist)] = speed[math.floor(i*dist)] + 1
	end
	
	Audio.Pitch(n/d)
end

attackToBG = {noose = "Sayori", knife = "Yuri", cupcake = "Natsuki", button = "Monika", Amy = "Amy"}

function GetAttackFamily(n)
	if (safe) then
		return "None"
	else
		local p = n:find("/")
		if not(p == nil) then
			s = n:sub(1,p-1)
			return attackToBG[s]
		else
			return "None"
		end
	end
end

function Heal(a)
	Player.Heal(a)
	if Player.hp == Player.maxhp then
		return "Your HP was maxed out."
	else
		return "You recovered " .. a .. " HP."
	end
end

function Accident()
	if not GetAlMightyGlobal("MonikaAccident") then
		nextwaves = {"starter"}
		State("DEFENDING")
		SetAlMightyGlobal("MonikaAccident", true)
		canAcc = false
	end
end