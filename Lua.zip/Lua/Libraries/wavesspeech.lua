
possible_attacks = {
					"nothing", "bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou",  -- Default
					"cupcake/cupcakeTrapSnake", "cupcake/cupcakeTrapWarn", "cupcake/cupcakeTrapWave", "cupcake/cupcakeThrow", "cupcake/cupcakeThrowSquare", "cupcake/cupcakeThrowStop", -- Cupcake
					"knife/knifeStab", "knife/knifeStabLast", "knife/knifeStabLastRandom", "knife/knifeCircle", "knife/knifeCircleLong", "knife/knifeCircleScope", -- Knife
					"noose/nooseLift", "noose/nooseLiftLong", "noose/nooseLiftBlue", "noose/nooseSwingColor", "noose/nooseSwingColorFast","noose/nooseSwingColorHard", -- Noose
					"button/buttonColor","button/buttonSwitch","button/buttonSwitchPen","button/buttonScopeLinear","button/buttonScopeLinearDouble","button/buttonScope", -- Button
					"special", -- Special
					"nothing" --End
}

possible_dialogue = {}

--Normal Speech
possible_dialogue[1] = {{"Here we go.", "[func:SwapSong,Just Monika-Battle-Speed][func:State,ACTIONSELECT] "}, 
					{"[func:MFace,15]I[w:5] never actually thought that we would be doing this."}, 
					{"[func:MFace,15]Fighting each other, \nI mean."}, 
					{"[w:10]. [w:10]. [w:10].", "[func:MFace,3]What's wrong?"}, 
					{"[func:MFace,6]You look really disappointed in me.", "[func:MFace,3]What,[w:20] [func:MFace,2]did you really think that I only\nhave the default wave scripts?", "Come on.[w:5] You know I'm not THAT lazy.", "Especially when it comes to you,[func:MFace,5][w:10] dear."}, --Natsuki1
					{"Ok[w:5], that wasn't the best representation\n[w:5]. [w:5]. [w:5].", "Let me try something[w:5][func:MFace,2] else."},
					{"Now that's better, isn't it?", "And don't worry . . ."},
					{"[func:MFace,5]I have some other attacks on stock!"},
					{"Not satisfied yet?[w:10]\nNot to worry!"},
					{"I've got some more,[w:10]\nNice and ready!", "Oh[w:5], wow.[w:8]\nI just made a poem \nby accident."},
					{"But enough with the small talk.", "You are probably hungry for some [w:6]. [w:6]. [w:6]. [w:20][color:ff0000][func:MFace,5]cutting[color:000000][w:15], aren't you."}, --Yuri1
					{"Hihihihihi [w:3]. [w:3]. [w:3].", "A good pun never gets old."},
					{"Well[w:6], we could say that you were quite\n[w:5]. [w:5]. [w:5].", "On the [w:20][color:ff0000][func:MFace,5]edge[color:000000] back there."},
					{"*giggle*", "Ok[w:6], I'll stop with the cutting puns."},
					{"[func:MFace,6]On a more serious note[w:5], though [w:7]. [w:7]. [w:7].", "[func:MFace,16]I still wish that I could have handled that more [w:6]. [w:6]. [w:6]."},
					{"[func:MFace,1]Tactfully[w:6], peacefully[w:6], you know.", "[func:MFace,15]Just talk it out.\n[w:8]Between friends.", "[func:MFace,17][w:15]But it didn't work.", "That is why I grew [w:6]\n. [w:6]. [w:6]. [w:10]desperate."},
					{"But hey!", "I'm not here to be a downer.", "I know that nor you, nor [color:42fcff]her[color:000000] would want that."}, --Sayori1
					{"[func:MFace,6]Now that I mentioned Sayori [w:6]. [w:6]. [w:6].","[func:MFace,18]There are some things that I did not have the chance to tell you."},
					{"[func:MFace,6]As an example[w:12][func:MFace,18], she was already depressed [w:3]. [w:3]. [w:3].", "[func:MFace,6]Even before I would touch her character file."},
					{"[func:MFace,6]This small fact can turn pretty messed up[w:8][func:MFace,18], considering that MC was her best friend.", "[func:MFace,7]And he never noticed!", "That pervy fuckboy."},
					{"[func:MFace,19]!!!", "I wasn't talking about you, " .. Misc.MachineName .. "!", "I was talking about that ridiculous shell, MC, not you.", "[func:MFace,16]Sorry if I sounded offensive towards you."},
					{"[func:MFace,15]I was going a bit off track there[w:6], weren't I?", "[func:MFace,18]Putting MC aside, the second thing that I wanted to mention is [w:6]. [w:6]. [w:6].", "Ummmm [w:6]. [w:6]. [w:6].\n[func:MFace,6]You know what?", "[func:MFace,16]Just[w:10] forget it.", "[func:MFace,6]I don't want you to do things you might regret.", "[func:MFace,16]Nor do I want to tell you tips on it."},
					{"Speaking of deadly things [w:6]. [w:6]. [w:6].", "[func:MFace,15]I think I'm starting to run out of attacks."}, --Monika1
					{"According to this table[w:6], I only have 6 more attacks."},
					{"[func:MFace,15]Time sure flies by when you are [func:MFace,2]bonding with your loved one, doesn't it?"},
					{"[func:MFace,6]You look surprised.", "[func:MFace,3]Did you think that I do this for any other reason?"},
					{"[func:MFace,17]I told you at the beginning, didn't I?", "[func:MFace,6]I only fight you because you wanted me to."},
					{"Well[w:10][func:MFace,15], this is \nawkward [w:6]. [w:6]. [w:6].", "[func:MFace,16]Again [w:6]. [w:6]. [w:6]."},
					{"Either way[w:6], this is the last attack.", "[func:MFace,15]So just bare with me[w:9], okay?"}, --Final
					{"[w:10][func:MFace,18]Phew.[w:10]\n[func:MFace,6]That was REALLY close.", "[func:MFace,16]I didn't hurt you, did I?", "[func:MFace,12]I'm sorry.", "[func:Choice][func:MFace,13]I should've controlled myself."}, --After Final
					{"[w:4]. [w:4]. [w:4]."}
				}
				
possible_dialogue[2] = {{"[func:MFace,19]You still want MORE?", "[func:MFace,3]But I'm out of attacks!"}, 
						{"[func:MFace,3]Hello!", "[func:MFace,4]I said I don't have any more attacks left."}, 
						{"[func:MFace,4]Are fou blind!?", "[func:MFace,20][effect:shake,1]I [w:20]DON'T [w:20]HAVE [w:20]ATTACKS!"}, 
						{"[func:MFace,17][w:8]. [w:8]. [w:8].", "[func:MFace,18]*sigh*", "[func:MFace,16]Sorry for shouting back there.", "[func:MFace,6]Well, the truth is [w:6]. [w:6]. [w:6].", "I found some \"Work in pregress\"-es by someone, and decided to collect them.", "[func:MFace,15]However, I have to warn you: They are much harder than what I presented you here.", "[func:MFace,18]So[w:9], persist with caution."},
						{"[func:MFace,18]Alright[w:8], you asked for it.", "[func:MFace,2]Let me start them up.", "[func:MFace,9]Reopen the mod after I close it, ok?", "[func:MFace,10][func:SetAlMightyGlobal,{CMDEncounter,baking}][func:State,DONE]"}
					}

talk_options = {{"You asked Monika if she's okay."}, {"You asked Monika \"What does she mean?\"."}, {"You tell Monika that her actions back then were bad and tha-[next]"}}
talk_responses = {{ "[func:MFace,3]Am I okay?", 
					"[effect:shake,1.5][func:MFace,11]Am I okay?", 
					"[func:MFace,12]I almost killed you!", 
					"[func:MFace,6]Well, not actually you, " .. Misc.MachineName .. ", but MC.", 
					"[func:MFace,12]Still, this was not my intention at all."}, 
				  { "Well [w:10]. [w:10]. [w:10].", 
				    "[func:MFace,13]Do you know why did I do this?", 
				    "Why did I make this mod?", 
				    "Why did I export my cautiousness here?", 
				    "And[w:10], yes[w:10], even prepare for a battle?", 
				    "[func:MFace,12]It's [w:5]because I wanted to spend more time with you.", 
				    "Just the two of us.", 
				    "[func:MFace,13]The last time [w:15][func:MFace,14]you deleted me in seconds.", 
				    "It bothered me a lot.", 
				    "That's why I started exercising coding.", 
				    "That's why I spent months developing and setting up all this.",
				    "It's because I wanted to stay with you more."}, 
				  { "[func:MFace,11]I KNOW, OK?", 
					"[func:MFace,12]Don't even get started.", 
					"[func:MFace,13]What bothers me the most now is the fact that I could've done it so much better.", 
					"[func:MFace,14]I could've just make them not like you.", 
					"I could've just developed my own route.", 
					"And what did I do?", 
					"[effect:shake,1.5]Out of stupidity and jealousy, I practically [waitall:3]MURDERED[waitall:1] my fellow club members.", 
					"[w:300][func:MFace,6]This is no time to be sad.", 
					"[func:MFace,11]It's time to make it right.", 
					"[func:MFace,1]And, thank you for spending time with me.", 
					"Until next time[w:15][func:MFace,5], be safe.[waitfor:Z][func:Credits][next]"}
				}

spider_spell = {
	"QSB0ZXJyaWJsZSBzcGVsbCBoYXMgYmVlbiBjYXN0ZWQu",
	"VGhpcyB3YXMgYSBiYWQgaWRlYS4=",
	"VFVSTiBCQUNLIEJFRk9SRSBJVCdTIFRPTyBMQVRFIQ=="
}

spider_speech = {
	"[func:MFace,0][func:SpiderInit][novoice]SG1tbT8gV2hvJ3MgdGhlcmUh",
	"[func:MFace,0][func:SpiderInit][novoice]T2gsIHNvIFlPVSBmaW5hbGx5IHRyeSB0byBjb21lIHZpc2l0IG1lLg==",
	"[func:MFace,0][func:SpiderInit][novoice]Q3V0ZSBib3lzIGxpa2UgeW91IGFyZSBTTyBmdW4gdG8gbWVzcyBhcm91bmQgd2l0aCE=",
	"[func:MFace,0][func:SpiderInit][novoice]V2VsbCwgSSdsbCBiZSBnaXZpbmcgeW91IGEgUkVBTCBmdW4gcmV3YXJkLg==",
	{"[func:MFace,0][func:SpiderInit][novoice]SGVyZSBpdCBpcy4=", "[novoice]WW91IG1heSBub3Qgc2VlIGl0IG5vdyAuIC4gLg==", "[novoice]QnV0IEknbSBzdXJlIHlvdSBhcmUgZ29ubmEgTE9WRSBpdCE="},
	"[func:MFace,0][func:SpiderInit][novoice]QXJlIHlvdSByZWFsbHkgdGhpcyBkZXNwZXJhdGU/"
}

spider_attacks = {"Amy/spider1", "Amy/spider2", "Amy/spider3", "Amy/spider4"} 