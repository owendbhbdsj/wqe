
BGMonika = {}
BGAnimFuncs.start.Monika = function()
	BGMonika.sprite = CreateSprite("SpecialBG/Monika2", "BelowUI")
	BGMonika.animation = {"SpecialBG/Monika1", "SpecialBG/Monika2"}
	BGMonika.sprite.alpha = 0.6
	BGMonika.sprite.Move(0, 25)
	BGMonika.timer = 0
	BGMonika.wait = 30
	BGMonika.spriteID = 1
end

BGAnimFuncs.update.Monika = function()
	BGMonika.timer = BGMonika.timer + 1
	if (BGMonika.timer == BGMonika.wait) then
		BGMonika.spriteID = BGMonika.spriteID + 1
		BGMonika.sprite.Set(BGMonika.animation[(BGMonika.spriteID%2)+1])
		BGMonika.timer = 0
		BGMonika.wait = math.random(5, 15)
	end
end

BGAnimFuncs.fin.Monika = function()
	BGMonika.sprite.Remove()
	BGMonika = {}
end
