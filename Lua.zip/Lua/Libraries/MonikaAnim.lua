
monika = {}

monika.legs = CreateSprite("Monika/Legs", "BelowArena")
monika.legs.MoveTo(320, 270)

monika.torso = CreateSprite("Monika/Torso", "BelowArena")
monika.torso.MoveTo(320, 340)
monika.torso.SetParent(monika.legs)

monika.head = CreateSprite("Monika/Face1", "BelowArena")
monika.head.MoveTo(320, 382)
monika.head.SetParent(monika.torso)
monika.head.SendToBottom()

animtimer = 0 --The animation Timer

mftimer = 98  -- Monika fade timer
ismf = false  -- is Monika Fading
mfmult = -1   -- Monika fade multiplyer
mfspeed = 2  -- Monika fade speed
ignoreNextFade = false --I think this is self explanitory

mastate = 1 --Monika Animation State (1 - normal, 2 - Hit, 3 - Hit Miss, 4 - Shake)
mhmult = 20 --Monika Hurt Multiplier
msShakeMult = 5 --The pen's shake multiplyer
msDashMult = 1 --Monika Slash Dash Multiplyer (direction, to be more precise)
msRight = true --Monika Slash Right (is the next strike from the right?)
SBGtimer = 0 -- Special BackGround timer

st = 0

maarg = 0 --For Cross-Script Arguments

function MonikaAnimManager()
	
	speedTimer = speedTimer + 1
	for i=1, speed[(speedTimer % #speed) + 1] do
		if ismf and monika.legs.isactive then
			mftimer = mftimer + mfspeed*mfmult
			monika.legs.alpha = mftimer/100
			monika.torso.alpha = mftimer/100
			monika.head.alpha = mftimer/100
			if (mftimer <= 0 or mftimer >= 100) then
				ismf = false
			end
		end
			
		animtimer = animtimer + 1
		SBGtimer = SBGtimer + 1
		if mastate >= 1 and mastate <= #monikaAnims then
			monikaAnims[mastate]()
		end
		BGAnimFuncs.update[currBG]()
	end
end

monikaAnims = {}

monikaAnims[1] = function()
	monika.torso.MoveTo(0, 63 + (math.sin(math.rad(animtimer * 2)) * 2))
end

monikaAnims[2] = function()
	if (animtimer == 1) then
		monika.torso.MoveTo(0, 63)
		mhmult = 20
	end
	monika.legs.MoveTo(320 + math.sin(math.rad(animtimer * 30)) * mhmult, 270)
	if (animtimer % 3 == 0) then
		if (mhmult <= 0) then
			animtimer = 0
			mastate = 1
			MonikaExpression(1)
		else
			mhmult = mhmult - 2
		end
	end
end

monikaAnims[3] = function()
	if (animtimer == 1) then
		monika.legs.alpha = 0.5
		monika.torso.alpha = 0.5
		monika.head.alpha = 0.5
		monika.torso.MoveTo(0, 63)
		
		monika.flegs = CreateSprite("Monika/Legs", "BelowArena")
		monika.flegs.MoveTo(320, 270)

		monika.ftorso = CreateSprite("Monika/Torso", "BelowArena")
		monika.ftorso.SetParent(monika.flegs)
		monika.ftorso.MoveTo(0, 63)

		monika.fhead = CreateSprite("Monika/Face1", "BelowArena")
		monika.fhead.MoveTo(320, 375)
		monika.fhead.SetParent(monika.ftorso)
		monika.fhead.SendToBottom()
		
		monika.flegs.alpha = 0.5
		monika.ftorso.alpha = 0.5
		monika.fhead.alpha = 0.5
	end
	monika.legs.MoveTo(320 + math.sin(math.rad(animtimer * 5)) * 50, 270)
	monika.flegs.MoveTo(320 - math.sin(math.rad(animtimer * 5)) * 50, 270)
	if (animtimer == 180/5) then
		monika.legs.alpha = 1
		monika.torso.alpha = 1
		monika.head.alpha = 1
		
		monika.flegs.Remove()
		monika.flegs = nil
		
		monika.ftorso.Remove()
		monika.ftorso = nil
		
		monika.fhead.Remove()
		monika.fhead = nil
		
		animtimer = 0
		mastate = 1
	end
end

monikaAnims[4] = function()
	if animtimer == 1 then
		monika.torso.MoveTo(0, 63)

		monika.flegs = CreateSprite("Monika/Legs", "BelowArena")
		monika.flegs.MoveTo(320, 270)

		monika.ftorso = CreateSprite("Monika/Torso", "BelowArena")
		monika.ftorso.SetParent(monika.flegs)
		monika.ftorso.MoveTo(0, 63)

		monika.fhead = CreateSprite("Monika/Face1", "BelowArena")
		monika.fhead.MoveTo(320, 375)
		monika.fhead.SetParent(monika.ftorso)
		monika.fhead.SendToBottom()
		
		monika.flegs.alpha = 0
		monika.ftorso.alpha = 0
		monika.fhead.alpha = 0

		monika.fflegs = CreateSprite("Monika/Legs", "BelowArena")
		monika.fflegs.MoveTo(320, 270)

		monika.fftorso = CreateSprite("Monika/Torso", "BelowArena")
		monika.fftorso.SetParent(monika.fflegs)
		monika.fftorso.MoveTo(0, 63)

		monika.ffhead = CreateSprite("Monika/Face1", "BelowArena")
		monika.ffhead.MoveTo(320, 375)
		monika.ffhead.SetParent(monika.fftorso)
		monika.ffhead.SendToBottom()
		
		monika.fflegs.alpha = 0
		monika.fftorso.alpha = 0
		monika.ffhead.alpha = 0
	end
	if animtimer % 2 == 0 then
		monika.legs.MoveTo(320 + math.random(-50, 50)/20, 270 + math.random(-20, 20)/20)
	end
	if animtimer % 4 == 0 then
		local alpha1 = math.random(-10, 5)/10
		local alpha2 = math.random(-10, 5)/10
		monika.flegs.MoveTo(320 + math.random(-100, 100)/5, 270 + math.random(-40, 40)/5)
		monika.flegs.alpha = alpha1
		monika.ftorso.alpha = alpha1
		monika.fhead.alpha = alpha1
		monika.fhead.Set(monika.head.spritename)
		monika.fflegs.MoveTo(320 + math.random(-100, 100)/5, 270 + math.random(-40, 40)/5)
		monika.fflegs.alpha = alpha2
		monika.fftorso.alpha = alpha2
		monika.ffhead.alpha = alpha2
		monika.ffhead.Set(monika.head.spritename)
	end
end

function toggleMonika(speed, on)
	if (not ignoreNextFade) then
		if (on) then 
			mfmult = 1
			mftimer = 0
		else 
			mfmult = -1
			mftimer = 100
		end
		
		mfspeed = speed
		ismf = true
	else
		ignoreNextFade = false
	end
end

function MonikaExpression(_id)
	local id = _id or maarg
	monika.head.Set("Monika/Face" .. id)
end

function MonikaHand(_on)
	local on = _on or maarg
	if (on) then
		monika.torso.Set("Monika/TorsoA")
		monika.torso.SetPivot(0.03, 0.5)
		monika.torso.SetAnchor(0.03, 0.5)
		monika.head.SetPivot(-0.23, 0.5)
		monika.head.SetAnchor(-0.23, 0.5)
	else
		monika.torso.Set("Monika/Torso")
		monika.torso.SetPivot(0.5, 0.5)
		monika.torso.SetAnchor(0.5, 0.5)
		monika.head.SetPivot(0.5, 0.5)
		monika.head.SetAnchor(0.5, 0.5)
	end
end

function KillM()
	mastate = 10
	monika.legs.Dust( true, true)
	monika.torso.Dust( true, true)
	monika.head.Dust( true, true)

	monika.flegs.Remove()
	monika.ftorso.Remove()
	monika.fhead.Remove()

	monika.fflegs.Remove()
	monika.fftorso.Remove()
	monika.ffhead.Remove()
end

function ChangeBGTo(n)
	BGAnimFuncs.fin[currBG]()
	currBG = n
	BGAnimFuncs.start[n]()
end

currBG = "None"

BGAnimFuncs = {start = {}, update = {}, fin = {}}

require "SayoriBGAnim"
require "YuriBGAnim"
require "NatsukiBGAnim"
require "MonikaBGAnim"
require "AmyBGAnim"

BGAnimFuncs.start.None = function()

end

BGAnimFuncs.update.None = function()

end

BGAnimFuncs.fin.None = function()

end