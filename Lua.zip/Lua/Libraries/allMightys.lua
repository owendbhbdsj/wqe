
CreateLayer("Disclaimer", "BelowArena")

require "TheDevsVent"

function AlMightySetUp()
	local disclaimerText = ""

	if (GetAlMightyGlobal("MonikaRunId") == nil) then
		SetAlMightyGlobal("MonikaLastRun", "none")
		disclaimer = true
		if (safe) then
			disclaimerText = {{"[color:ff0000]DISCLAIMER!\n[color:ffffff]This fan-game/mod/project/whatever...", "Contains heavy [color:ff0000]SPOILERS[color:ffffff] from the two really popular indie games:\n[w:3]. [w:3]. [w:3].","\r[color:ff0000]Undertale[color:ffffff] and [color:ff66cc]Doki Doki Literature Club[color:ffffff].", "If, by any chance, you haven't completed either one of the mentioned games [w:3]. [w:3]. [w:3].", "You should [color:ff0000]NOT[color:ffffff] play this fan game. Ok?", "So, if you wanna quit [w:4]. [w:4]. [w:4].[w:5]\nJust press [ESC] and leave.\n[w:10]Nobody is gonna get mad.", "It's for the better if you don't get spoiled[w:2], trust me.", "They are both an experience for\ra lifetime.","They are both purchaseable on [color:0000cc]Steam[color:ffffff].[w:15] ([color:ff66cc]Doki Doki Literature Club[color:ffffff] is even free.)", 
				"[w:6]. [w:6]. [w:6].[w:7]\nYou are still here, I see.", "So, I guess we both now what I'm talking about, right?", "Or you \"Just don't mind spoilers,[w:3] that's all.\"?", "Regardless,[w:3] I must warn you about something else as well.", "This game [w:8]. [w:8]. [w:8].[w:8] contains themes of [color:ff0000]suicide[color:ffffff][w:2], [color:555555]depression[color:ffffff] [w:2]and [color:ffff00]self harm[color:ffffff].", "If you are not fond of said subjects[w:3], then [color:00c000]PLEASE[color:ffffff] leave this game be.", "And while we are on the topic,[w:5] I beg you not to do anything that you might regret.", "[color:00c000]Because someone really cares about you.", "I don't want to sound monotone and predictable [w:4]. [w:4]. [w:4].", "But if you have thoughts of that nature,[w:3] then [color:00c000]please[color:ffffff] seek help.",
				"Nobody wants you dead or missing,[w:3] you know.", "Lastly[w:3], there are MANY flashing images in this mod![w:6]\nIf you have epilepsy, I would not recommend playing!", "So[w:3], if you don't want to quit, then, here[w:2], I'll let you play.[w:6]\nThank you for reading!", 
				"[w:3]. [w:3]. [w:3]. [w:3]Wait a second.", "Is that [w:10]Safe Mode [w:2]O[w:2]N[w:2]?", "Did you seriously activate Safe Mode?", "Pfffffffffffffft...[w:2][next]", "HAHAHAHAHAHAHAHAHAHAH", "You actually did it.[w:7]\nYou are using Safe Mode right now.", "WOOOOOW. [w:10]Huuh.", "This is HILARIOUS.", "And do you know why?", "Because all you could've done was \r[w:3]. [w:3]. [w:3].[w:4][next]", "To not play the freaking game!", "It was entirely YOUR choice![w:5]\nI don't think that anyone would force you to do this.", "So,[w:2] next time,[w:3] either deactivate that childish thing or don't play the game.", "See?[w:4] It's that simple!","But[w:4], you know what?", "I'll let you play.", "Let's see what good your little safety button does against this mod!", "[waitall:2]Enjoy ;)"}, 5}
		else
			disclaimerText = {{"[color:ff0000]DISCLAIMER!\n[color:ffffff]This fan-game/mod/project/whatever...", "Contains heavy [color:ff0000]SPOILERS[color:ffffff] from the two really popular indie games:\n[w:3]. [w:3]. [w:3].","\r[color:ff0000]Undertale[color:ffffff] and [color:ff66cc]Doki Doki Literature Club[color:ffffff].", "If, by any chance, you haven't completed either one of the mentioned games [w:3]. [w:3]. [w:3].", "You should [color:ff0000]NOT[color:ffffff] play this fan game. Ok?", "So, if you wanna quit [w:4]. [w:4]. [w:4].[w:5]\nJust press [ESC] and leave.\n[w:10]Nobody is gonna get mad.", "It's for the better if you don't get spoiled[w:2], trust me.", "They are both an experience for\ra lifetime.","They are both purchaseable on [color:0000cc]Steam[color:ffffff].[w:15] ([color:ff66cc]Doki Doki Literature Club[color:ffffff] is even free.)", 
				"[w:6]. [w:6]. [w:6].[w:7]\nYou are still here, I see.", "So, I guess we both now what I'm talking about, right?", "Or you \"Just don't mind spoilers,[w:3] that's all.\"?", "Regardless,[w:3] I must warn you about something else as well.", "This game [w:8]. [w:8]. [w:8].[w:8] contains themes of [color:ff0000]suicide[color:ffffff][w:2], [color:555555]depression[color:ffffff] [w:2]and [color:ffff00]self harm[color:ffffff].", "If you are not fond of said subjects[w:3], then [color:00c000]PLEASE[color:ffffff] leave this game be.", "And while we are on the topic,[w:5] I beg you not to do anything that you might regret.", "[color:00c000]Because someone really cares about you.", "I don't want to sound monotone and predictable [w:4]. [w:4]. [w:4].", "But if you have thoughts of that nature,[w:3] then [color:00c000]please[color:ffffff] seek help.",
				"Nobody wants you dead or missing,[w:3] you know.", "Lastly[w:3], there are MANY flashing images in this mod![w:6]\nIf you have epilepsy, I would not recommend playing!", "So[w:3], if you don't want to quit, then, here[w:2], I'll let you play.[w:6]\nThank you for reading!"}, 5}
		end
	end
	
	if (not safe) and (GetAlMightyGlobal("MonikaRunId") ~= nil) then
		SetAlMightyGlobal("MonikaRunId", GetAlMightyGlobal("MonikaRunId") + 1)
	end

	if (GetAlMightyGlobal("MonikaAct")) then
		enemies[1]["commands"] = {"Check", "Talk" ,"Flirt"}
	end

	alMightyFunc = {}

	alMightyFunc.none = function()
		introDialogue = {"Yey. I managed to get it to work.", "Hello, " .. Misc.MachineName .. ". Long time no see.", "The last time I saw you, I was really bad at coding.", "But that has changed, since I started exercising programming.", "And, to be completely honest, it's not that hard once you understand what does what.", "And this is the proof of it!", "I managed to transfer myself to this game engine.", "I'm so exited to talk to you more.", "In the meantime, I can also try out some of the so called \"Text Commands\" this engine has to offer.", "I'm so delighted that I got this to work, I don't even know where to start!", "(Ok[w:10], Monika[w:10], deep breaths.)", "I'll collect my thoughts and then we can continue from where we left off, ok?", "[w:600]What? Are you proposing for us to ...", "FIGHT?", "Well, as much as I'd like to know you better, there is no way on earth I would harm you intentionally.", "Besides, we live in two separate worlds. How would that even be possible?","[w:60]Oh, you meant, like, MC and I.", "Sorry I misunderstood. That actually makes much more sense.", "Well, as much as this engine is compatible with it.", "I mean, it was created for that very purpose originally.", "Still, I could never harm you.", "Besides, fighting is not my favorite thing to do.", "Far from it, actually.", "[w:90]Stop it, please!", "I already told you. I don't want to!", "[w:30]. [w:10] .[w:10] .[w:20] Fine, fine! I'll do it.", "I'll fight you, ok?", "But just because you wanted it, nothing else.", "I just hope that nothing will break."}
	end

	alMightyFunc.err = function()
		introDialogue = {"Ouch! That hurt!", "What happened, " .. Misc.MachineName .. "?", "Did an error occur?", "Or did you just close the game on me?", "Either way, it wasn't a pleasant experience.", "Shall we try again?"}
	end

	alMightyFunc.death = function()
		local dial = {{"[noskip]Well, looks like I won this fight.", "[w:30]Huh, you still want more?", "All right ~."}, {"Is this enough?", "[w:30]No? [w:20]Ok then."}, {"Let me guess.", "You want to try again[w:6], don't you.", "Then here."}, {"*sigh*" ,"Let's get this done."}}
		introDialogue = dial[math.min(GetAlMightyGlobal("MonikaRunId"), #dial)]
	end

	alMightyFunc.win = function()
		introDialogue = {"[noskip][w:10]You shouldn't be able to see this!"}
	end

	alMightyFunc.quit = function()
		local dial = {{"[noskip]Why did you leave?", "You were almost there."}, {"C'mon.", "Quitting is not nice to do, you know."}, {"Please accept the consequences of your actions.", "I do."}}
		introDialogue = dial[math.random(1, #dial)]
	end

	alMightyFunc[GetAlMightyGlobal("MonikaLastRun")]()
	
	for i=1, #introDialogue do introDialogue[i] = "[noskip][font:ddlc][novoice]" .. introDialogue[i] end
	table.insert(introDialogue, "[noskip][func:introEnd][w:999] ")

	SetAlMightyGlobal("MonikaLastRun", "err")
	
	if (not disclaimer) and (GetAlMightyGlobal("MonikaWins") > 0 and (not safe)) then
		SetAlMightyGlobal("DevTalk", math.min(GetAlMightyGlobal("DevTalk") + 1, #my_words))
		disclaimerText = {my_words[GetAlMightyGlobal("DevTalk")], 10, true}
	end
	if (not disclaimer) and (safe and GetAlMightyGlobal("MonikaRunId") > 1) then
		disclaimerText = {{"You already played this [w:5]. [w:5]. [w:5].", "And NOW you come with that Safe Mode shit?", "How low can you get?"}, 2, true}
	end
	if type(disclaimerText) == "table" then
		Disclaimer(disclaimerText[1], disclaimerText[2], disclaimerText[3])
	else
		introStart()
	end
end

function Disclaimer(t, w, c)
	local nope = c or false
	--DEBUG(tostring(enemies[1]))
	--DEBUG(tostring(enemies[1]["disclaimerStart"]))
	enemies[1].Call("disclaimerStart")
	Audio.Stop()
	local text = t or {}
	wait = w or 0
	for k,v in pairs(text) do text[k] = v .. "[w:".. wait .."][novoice] " end
	BattleDialog(text)
	enemies[1]["currentdialogue"] = "[func:DisclaimerDone]" .. (nope and "[func:State,DONE]" or "[func:introStart][next]")
end

function DisclaimerDone()
	if disclaimer then
		SetAlMightyGlobal("MonikaRunId", 1)
		SetAlMightyGlobal("MonikaLastRun", "err")
		SetAlMightyGlobal("MonikaWins", 0)
		SetAlMightyGlobal("MonikaAct", false)
		SetAlMightyGlobal("DevTalk", 0)
	end
end

--enemies[1]["DisclaimerDone"] = function() Encounter.Call("DisclaimerDone") end