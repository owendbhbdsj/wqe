
Natsuki = {}

BGAnimFuncs.start.Natsuki = function()
	Natsuki.sprite = CreateSprite("SpecialBG/Natsuki2", "BelowUI")
	Natsuki.animation = {"SpecialBG/Natsuki2", "SpecialBG/Natsuki1", "SpecialBG/Natsuki2", "SpecialBG/Natsuki3"}
	Natsuki.sprite.alpha = 0.6
	Natsuki.sprite.Move(0, 25)
	Natsuki.timer = 0
	Natsuki.wait = 30
	Natsuki.spriteID = 1
end

BGAnimFuncs.update.Natsuki = function()
	Natsuki.timer = Natsuki.timer + 1
	if (Natsuki.timer == Natsuki.wait) then
		Natsuki.spriteID = Natsuki.spriteID + 1
		Natsuki.sprite.Set(Natsuki.animation[(Natsuki.spriteID%4)+1])
		Natsuki.timer = 0
		Natsuki.wait = math.random(20, 30)
	end
end

BGAnimFuncs.fin.Natsuki = function()
	Natsuki.sprite.Remove()
	Natsuki = {}
end