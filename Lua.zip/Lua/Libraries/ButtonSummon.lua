
function CreateButton(c, tc, t)
	local btn = CreateProjectile("Button", 1000, 1000)
	btn.setVar("color", c)
	btn.sprite.color32 = GetColor(c)
	
	local txt = CreateProjectile((t and "Monika" or "Just Monika"), 1000, 1000)
	txt.setVar("color", tc)
	txt.sprite.SetParent(btn.sprite)
	txt.sprite.color32 = GetColor(tc)
	
	btn.setVar("text", txt)
	
	return btn
end

function GetColor(n)
	if (n == "w") then
		return {255, 255, 255}
	elseif (n == "c") then
		return {66, 252, 255}
	elseif (n == "o") then
		return {252, 166, 0}
	elseif (n == "g") then
		return {100, 100, 100}
	elseif (n == "b") then
		return {0, 0, 0}
	end
end